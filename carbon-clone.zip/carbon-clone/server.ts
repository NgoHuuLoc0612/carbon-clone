/**
 * Carbon Clone - Puppeteer Screenshot Server
 * Provides high-fidelity exports via headless Chromium
 */

import express from 'express'
import cors from 'cors'
import puppeteer, { Browser, Page } from 'puppeteer'

const app = express()
const PORT = 3001

app.use(cors({ origin: 'http://localhost:5173' }))
app.use(express.json({ limit: '10mb' }))

let browser: Browser | null = null

async function getBrowser(): Promise<Browser> {
  if (!browser || !browser.connected) {
    browser = await puppeteer.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--font-render-hinting=none',
        '--disable-font-subpixel-positioning',
      ],
    })
  }
  return browser
}

interface ScreenshotOptions {
  html: string
  css: string
  width: number
  height: number
  scale: number
  format: 'png' | 'jpeg' | 'webp'
  quality?: number
  selector?: string
}

app.post('/api/screenshot', async (req, res) => {
  const opts: ScreenshotOptions = req.body

  let page: Page | null = null
  try {
    const b = await getBrowser()
    page = await b.newPage()

    // Set viewport with device scale factor for retina quality
    await page.setViewport({
      width: opts.width + 128,
      height: opts.height + 128,
      deviceScaleFactor: opts.scale || 2,
    })

    const fullHtml = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { 
    background: transparent; 
    display: flex; 
    align-items: center; 
    justify-content: center;
    min-height: 100vh;
    padding: 24px;
  }
  ${opts.css}
</style>
</head>
<body>
${opts.html}
</body>
</html>`

    await page.setContent(fullHtml, { waitUntil: 'networkidle0' })

    // Wait for fonts to load
    await page.evaluateHandle('document.fonts.ready')

    // Additional wait for any async rendering
    await new Promise(r => setTimeout(r, 300))

    let screenshotBuffer: Buffer

    if (opts.selector) {
      const element = await page.$(opts.selector)
      if (!element) throw new Error(`Selector "${opts.selector}" not found`)
      screenshotBuffer = await element.screenshot({
        type: opts.format === 'jpeg' ? 'jpeg' : opts.format === 'webp' ? 'webp' : 'png',
        quality: opts.format !== 'png' ? (opts.quality || 95) : undefined,
        omitBackground: opts.format === 'png',
      }) as Buffer
    } else {
      screenshotBuffer = await page.screenshot({
        type: opts.format === 'jpeg' ? 'jpeg' : opts.format === 'webp' ? 'webp' : 'png',
        quality: opts.format !== 'png' ? (opts.quality || 95) : undefined,
        omitBackground: opts.format === 'png',
        fullPage: false,
        clip: {
          x: 0,
          y: 0,
          width: opts.width + 128,
          height: opts.height + 128,
        },
      }) as Buffer
    }

    const mimeTypes = {
      png: 'image/png',
      jpeg: 'image/jpeg',
      webp: 'image/webp',
    }

    res.set('Content-Type', mimeTypes[opts.format] || 'image/png')
    res.send(screenshotBuffer)
  } catch (err) {
    console.error('Screenshot error:', err)
    res.status(500).json({ error: String(err) })
  } finally {
    if (page) await page.close().catch(() => {})
  }
})

// SVG → PNG via puppeteer (alternative to resvg-wasm)
app.post('/api/svg-to-png', async (req, res) => {
  const { svg, scale = 2 } = req.body as { svg: string; scale?: number }

  let page: Page | null = null
  try {
    const b = await getBrowser()
    page = await b.newPage()

    // Parse SVG dimensions
    const widthMatch = svg.match(/width="([^"]+)"/)
    const heightMatch = svg.match(/height="([^"]+)"/)
    const width = widthMatch ? parseInt(widthMatch[1]) : 800
    const height = heightMatch ? parseInt(heightMatch[1]) : 600

    await page.setViewport({ width, height, deviceScaleFactor: scale })

    const html = `<!DOCTYPE html>
<html>
<head><style>
  * { margin: 0; padding: 0; }
  body { width: ${width}px; height: ${height}px; overflow: hidden; }
  svg { width: 100%; height: 100%; }
</style></head>
<body>${svg}</body>
</html>`

    await page.setContent(html, { waitUntil: 'networkidle0' })
    await page.evaluateHandle('document.fonts.ready')

    const buf = await page.screenshot({
      type: 'png',
      omitBackground: true,
      clip: { x: 0, y: 0, width, height },
    }) as Buffer

    res.set('Content-Type', 'image/png')
    res.send(buf)
  } catch (err) {
    console.error('SVG→PNG error:', err)
    res.status(500).json({ error: String(err) })
  } finally {
    if (page) await page.close().catch(() => {})
  }
})

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', browser: browser?.connected ?? false })
})

// Graceful shutdown
process.on('SIGTERM', async () => {
  if (browser) await browser.close()
  process.exit(0)
})

app.listen(PORT, () => {
  console.log(`🚀 Carbon Clone server running on http://localhost:${PORT}`)
  // Pre-warm the browser
  getBrowser().then(() => console.log('🌐 Browser ready'))
})

export default app
