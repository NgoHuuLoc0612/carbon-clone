// ─── Background Types ──────────────────────────────────────────────────────

export type BackgroundType = 'solid' | 'gradient' | 'image' | 'transparent'

export interface GradientStop {
  color: string
  position: number // 0-100
}

export interface BackgroundConfig {
  type: BackgroundType
  solid: string
  gradient: {
    angle: number
    stops: GradientStop[]
  }
  imageUrl: string
  blur: number
}

// ─── Shadow Types ──────────────────────────────────────────────────────────

export interface ShadowConfig {
  enabled: boolean
  x: number
  y: number
  blur: number
  spread: number
  color: string
  inset: boolean
}

// ─── Window Chrome Types ───────────────────────────────────────────────────

export type WindowStyle = 'mac' | 'windows' | 'none'
export type WindowButtonStyle = 'colorful' | 'mono' | 'outline'

export interface WindowConfig {
  style: WindowStyle
  buttonStyle: WindowButtonStyle
  title: string
  showTitle: boolean
  showLine: boolean
}

// ─── Editor Config ─────────────────────────────────────────────────────────

export interface PaddingConfig {
  top: number
  right: number
  bottom: number
  left: number
  linked: boolean
}

export interface EditorConfig {
  code: string
  language: string
  theme: string
  fontFamily: string
  fontSize: number
  lineHeight: number
  tabSize: number
  showLineNumbers: boolean
  firstLineNumber: number
  lineNumberStart: number
  showWhiteSpace: boolean
  wrapLines: boolean
}

// ─── Watermark ─────────────────────────────────────────────────────────────

export interface WatermarkConfig {
  enabled: boolean
  text: string
  position: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left'
  opacity: number
}

// ─── Full App State ────────────────────────────────────────────────────────

export interface AppState {
  editor: EditorConfig
  background: BackgroundConfig
  shadow: ShadowConfig
  window: WindowConfig
  padding: PaddingConfig
  watermark: WatermarkConfig
  borderRadius: number
  width: number | 'auto'
  // UI state
  isExporting: boolean
  exportProgress: number
  exportError: string | null
  activePanel: string
}

// ─── Export Types ──────────────────────────────────────────────────────────

export type ExportFormat = 'png' | 'svg' | 'jpeg' | 'mp4' | 'gif' | 'webp'
export type ExportQuality = 'draft' | 'standard' | 'high' | 'ultra'

export interface ExportOptions {
  format: ExportFormat
  quality: ExportQuality
  scale: number
  method: 'html-to-image' | 'puppeteer' | 'resvg'
  // For video exports
  animation?: AnimationConfig
}

// ─── Animation Types ───────────────────────────────────────────────────────

export type AnimationType = 'typing' | 'fade-in' | 'slide-up' | 'highlight-scan' | 'none'

export interface AnimationConfig {
  type: AnimationType
  duration: number // ms
  fps: number
  delay: number
}

// ─── Theme Info ────────────────────────────────────────────────────────────

export interface ThemeInfo {
  id: string
  name: string
  type: 'dark' | 'light'
  preview: string // background color for preview swatch
}

// ─── Language Info ─────────────────────────────────────────────────────────

export interface LanguageInfo {
  id: string
  name: string
  aliases: string[]
  extensions: string[]
}

// ─── Google Fonts ──────────────────────────────────────────────────────────

export interface GoogleFont {
  family: string
  variants: string[]
  subsets: string[]
  category: string
}

// ─── Tree-Sitter Analysis ──────────────────────────────────────────────────

export interface CodeAnalysis {
  errors: Array<{ startRow: number; startCol: number; endRow: number; endCol: number; message: string }>
  symbols: Array<{ name: string; type: string; row: number; col: number }>
  lineCount: number
  charCount: number
  complexity: number
}

// ─── Shiki Token ──────────────────────────────────────────────────────────

export interface HighlightedCode {
  html: string
  tokens: any[]
  bg: string
  fg: string
  themeName: string
}

// ─── Preset ────────────────────────────────────────────────────────────────

export interface Preset {
  id: string
  name: string
  description: string
  thumbnail?: string
  config: Partial<AppState>
}
