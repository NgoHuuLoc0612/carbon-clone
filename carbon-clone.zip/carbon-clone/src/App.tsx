import React, { useRef, useCallback, useState, useEffect } from 'react'
import { CodeEditor } from '@/components/Editor/CodeEditor'
import { CodeWindow, ShikiStyleInjector } from '@/components/Preview/CodeWindow'
import { ControlsPanel } from '@/components/Controls/ControlsPanel'
import { PresetsPanel } from '@/components/Controls/PresetsPanel'
import { ExportPanel } from '@/components/Export/ExportPanel'
import { Toolbar } from '@/components/UI/Toolbar'
import { DiffModal } from '@/components/Editor/DiffViewer'
import { useEditorStore } from '@/store/editorStore'
import { preloadCodingFonts } from '@/hooks/useGoogleFonts'
import { useCodeHistory } from '@/hooks/useCodeHistory'
import { getSharedStateFromCurrentUrl } from '@/utils/urlState'
import clsx from 'clsx'

type SidePanel = 'controls' | 'presets' | 'export'

export default function App() {
  const store = useEditorStore()
  const previewRef = useRef<HTMLDivElement>(null)
  const [sidePanel, setSidePanel] = useState<SidePanel>('controls')
  const [analysisData, setAnalysisData] = useState<any>(null)
  const [diffOpen, setDiffOpen] = useState(false)
  const [diffSnapshot, setDiffSnapshot] = useState<string>('')

  const history = useCodeHistory(store.editor.code)

  // Pre-load common coding fonts
  useEffect(() => {
    preloadCodingFonts([
      'JetBrains Mono',
      'Fira Code',
      'Source Code Pro',
      'IBM Plex Mono',
    ])
  }, [])

  // Load shared state from URL on first mount
  useEffect(() => {
    getSharedStateFromCurrentUrl().then(state => {
      if (state) {
        store.applyPreset(state as any)
        // Clear hash after loading
        window.history.replaceState(null, '', window.location.pathname + window.location.search)
      }
    })
  }, [])

  // Track code history whenever editor code changes
  useEffect(() => {
    history.pushSnapshot(store.editor.code)
  }, [store.editor.code])

  // Global keyboard shortcuts
  useEffect(() => {
    function handleKeydown(e: KeyboardEvent) {
      const mod = e.metaKey || e.ctrlKey

      if (mod && e.key === 'e') {
        e.preventDefault()
        setSidePanel('export')
      }

      // Undo/Redo for code history (beyond Monaco's own undo)
      if (mod && e.shiftKey && e.key === 'z') {
        e.preventDefault()
        const code = history.redo()
        if (code) store.setCode(code)
      }

      // Diff shortcut
      if (mod && e.key === 'd') {
        e.preventDefault()
        openDiff()
      }
    }
    window.addEventListener('keydown', handleKeydown)
    return () => window.removeEventListener('keydown', handleKeydown)
  }, [history, store])

  // Custom export event
  useEffect(() => {
    const handler = () => setSidePanel('export')
    document.addEventListener('carbon:export', handler)
    return () => document.removeEventListener('carbon:export', handler)
  }, [])

  const openDiff = useCallback(() => {
    // Take a snapshot of current code to compare later
    setDiffSnapshot(store.editor.code)
    setDiffOpen(true)
  }, [store.editor.code])

  // Grab previous snapshot for diff comparison (or empty)
  const prevCode = history.snapshots[Math.max(0, history.currentIndex - 1)]?.code ?? ''

  return (
    <div className="flex flex-col h-screen bg-[#0a0a0f] text-white overflow-hidden">
      <ShikiStyleInjector />

      {/* Toolbar */}
      <Toolbar
        onExport={() => setSidePanel('export')}
        onDiff={openDiff}
        activePanel={sidePanel}
        onPanelChange={setSidePanel}
      />

      {/* Main layout */}
      <div className="flex flex-1 min-h-0">
        {/* Left sidebar */}
        <div className="w-72 xl:w-80 flex-shrink-0 flex flex-col border-r border-white/[0.06] overflow-hidden">
          {sidePanel === 'controls' && <ControlsPanel />}
          {sidePanel === 'presets' && (
            <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: 'thin' }}>
              <PresetsPanel />
            </div>
          )}
          {sidePanel === 'export' && <ExportPanel previewRef={previewRef} />}
        </div>

        {/* Preview area */}
        <div
          className="flex-1 min-w-0 flex flex-col"
          style={{
            background: store.background.type === 'transparent'
              ? 'repeating-conic-gradient(#1a1a1a 0% 25%, #111111 0% 50%) 0 0 / 20px 20px'
              : '#0d0f14',
          }}
        >
          {/* Preview header */}
          <div className="flex items-center justify-between px-4 py-2 border-b border-white/[0.04] bg-[#0d0f14]/80 backdrop-blur-sm">
            <span className="text-xs text-white/25 font-mono uppercase tracking-widest">Preview</span>
            <div className="flex items-center gap-3 text-xs text-white/25">
              {analysisData && (
                <>
                  <span>{analysisData.lineCount} lines</span>
                  {analysisData.complexity > 0 && (
                    <span className={clsx(
                      'px-1.5 py-0.5 rounded',
                      analysisData.complexity <= 5  ? 'bg-green-900/30 text-green-500/70' :
                      analysisData.complexity <= 10 ? 'bg-yellow-900/30 text-yellow-500/70' :
                      'bg-red-900/30 text-red-500/70'
                    )}>
                      CC {analysisData.complexity}
                    </span>
                  )}
                </>
              )}
              <span className="opacity-50">·</span>
              <span>{store.editor.theme}</span>
              {history.canUndo && (
                <button
                  onClick={() => { const c = history.undo(); if (c) store.setCode(c) }}
                  className="text-white/30 hover:text-white/60 transition-colors"
                  title="Undo (history)"
                >
                  ↩
                </button>
              )}
              {history.canRedo && (
                <button
                  onClick={() => { const c = history.redo(); if (c) store.setCode(c) }}
                  className="text-white/30 hover:text-white/60 transition-colors"
                  title="Redo (history)"
                >
                  ↪
                </button>
              )}
            </div>
          </div>

          {/* Scrollable preview canvas */}
          <div className="flex-1 min-h-0 overflow-auto flex items-center justify-center p-8">
            <div className="relative">
              <CodeWindow ref={previewRef} />
            </div>
          </div>
        </div>

        {/* Right panel: Monaco editor */}
        <div className="w-[420px] xl:w-[500px] flex-shrink-0 flex flex-col border-l border-white/[0.06]">
          <div className="flex items-center justify-between px-4 py-2 border-b border-white/[0.06] bg-[#0d0f14]">
            <span className="text-xs text-white/25 font-mono uppercase tracking-widest">Code Editor</span>
            <div className="flex items-center gap-2 text-[10px] text-white/20 font-mono">
              <span>⌘D: diff</span>
              <span>·</span>
              <span>⌘E: export</span>
            </div>
          </div>

          <div className="flex-1 min-h-0">
            <CodeEditor onAnalysisUpdate={setAnalysisData} />
          </div>
        </div>
      </div>

      {/* Export progress overlay */}
      {store.isExporting && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-[#1a1d24] border border-white/10 rounded-2xl p-8 text-center max-w-xs w-full mx-4 shadow-2xl">
            <div className="mb-4">
              <svg className="animate-spin h-10 w-10 text-indigo-500 mx-auto" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"
                  strokeDasharray="48" strokeDashoffset="24" />
              </svg>
            </div>
            <p className="text-white font-semibold text-lg mb-1">Exporting…</p>
            <p className="text-white/40 text-sm mb-4">
              {store.exportOptions.format.toUpperCase()} via {store.exportOptions.method}
            </p>
            <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full transition-all duration-200"
                style={{ width: `${store.exportProgress}%` }}
              />
            </div>
            <p className="text-indigo-400 text-sm font-mono mt-2">{store.exportProgress}%</p>
          </div>
        </div>
      )}

      {/* Diff modal */}
      <DiffModal
        isOpen={diffOpen}
        onClose={() => setDiffOpen(false)}
        oldCode={prevCode}
        newCode={store.editor.code}
      />
    </div>
  )
}
