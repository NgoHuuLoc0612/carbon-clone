import * as htmlToImage from 'html-to-image'
import type { ExportOptions } from '@/types'

// ─── html-to-image export ─────────────────────────────────────────────────

const SCALE_MAP: Record<string, number> = {
  draft: 1,
  standard: 2,
  high: 3,
  ultra: 4,
}

export async function exportAsPng(
  element: HTMLElement,
  options: ExportOptions
): Promise<Blob> {
  const scale = options.scale || SCALE_MAP[options.quality] || 2

  const dataUrl = await htmlToImage.toPng(element, {
    pixelRatio: scale,
    cacheBust: true,
    skipFonts: true,
    
    
    filter: (node) => {
      // Skip UI controls, only include the preview
      return !node.classList?.contains('no-export')
    },
  })

  return dataUrlToBlob(dataUrl)
}

export async function exportAsJpeg(
  element: HTMLElement,
  options: ExportOptions
): Promise<Blob> {
  const scale = options.scale || SCALE_MAP[options.quality] || 2
  const qualityNum = { draft: 0.7, standard: 0.85, high: 0.92, ultra: 0.98 }[options.quality] || 0.92

  const dataUrl = await htmlToImage.toJpeg(element, {
    pixelRatio: scale,
    quality: qualityNum,
    cacheBust: true,
    skipFonts: true,
    filter: (node) => !node.classList?.contains('no-export'),
  })

  return dataUrlToBlob(dataUrl)
}

export async function exportAsWebp(
  element: HTMLElement,
  options: ExportOptions
): Promise<Blob> {
  const scale = options.scale || SCALE_MAP[options.quality] || 2

  const dataUrl = await htmlToImage.toBlob(element, {
    pixelRatio: scale,
    cacheBust: true,
    skipFonts: true,
    filter: (node) => !node.classList?.contains('no-export'),
  })

  return dataUrl || new Blob()
}

export async function exportAsSvg(element: HTMLElement): Promise<Blob> {
  const dataUrl = await htmlToImage.toSvg(element, {
    cacheBust: true,
    skipFonts: true,
    filter: (node) => !node.classList?.contains('no-export'),
  })

  // toSvg returns data:image/svg+xml;charset=utf-8,<encoded SVG>
  // NOT base64 — must use decodeURIComponent, not atob
  const svgContent = decodeURIComponent(dataUrl.split(',').slice(1).join(','))
  return new Blob([svgContent], { type: 'image/svg+xml' })
}

// ─── resvg-wasm SVG→PNG conversion ────────────────────────────────────────

let resvgInitialized = false

async function initResvg() {
  if (resvgInitialized) return
  const { initWasm } = await import('@resvg/resvg-wasm')
  // Load WASM from CDN or local
  try {
    const wasmUrl = new URL('@resvg/resvg-wasm/index_bg.wasm', import.meta.url).href
    await initWasm(fetch(wasmUrl))
  } catch {
    // Try alternative path
    await initWasm(fetch('/wasm/resvg.wasm'))
  }
  resvgInitialized = true
}

export async function svgToPngViaResvg(
  svgString: string,
  options: {
    scale?: number
    fontFamilies?: string[]
    defaultFontFamily?: string
  } = {}
): Promise<Blob> {
  await initResvg()
  const { Resvg } = await import('@resvg/resvg-wasm')

  const resvgOptions: any = {
    fitTo: {
      mode: 'zoom',
      value: options.scale || 2,
    },
    font: {
      loadSystemFonts: false,
      defaultFontFamily: options.defaultFontFamily || 'JetBrains Mono',
    },
    logLevel: 'error',
  }

  const resvgInstance = new Resvg(svgString, resvgOptions)
  const pngData = resvgInstance.render()
  const pngBuffer = pngData.asPng()

  return new Blob([pngBuffer.buffer as ArrayBuffer], { type: 'image/png' })
}

// ─── Puppeteer server export ───────────────────────────────────────────────

interface PuppeteerExportOptions {
  html: string
  css: string
  width: number
  height: number
  scale?: number
  format?: 'png' | 'jpeg' | 'webp'
  quality?: number
}

export async function exportViaPuppeteer(options: PuppeteerExportOptions): Promise<Blob> {
  const response = await fetch('/api/screenshot', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...options,
      scale: options.scale || 2,
      format: options.format || 'png',
    }),
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: response.statusText }))
    throw new Error(`Puppeteer export failed: ${err.error || response.statusText}`)
  }

  return response.blob()
}

// ─── Extract element HTML for Puppeteer ───────────────────────────────────

export function extractElementForExport(element: HTMLElement): { html: string; css: string } {
  // Clone element and clean up interactive/UI elements
  const clone = element.cloneNode(true) as HTMLElement

  // Remove elements with no-export class
  clone.querySelectorAll('.no-export').forEach(el => el.remove())

  // Extract computed styles for used font faces
  const usedFamilies = new Set<string>()
  clone.querySelectorAll('[style*="font-family"], [class]').forEach((el) => {
    const style = window.getComputedStyle(el as Element)
    const ff = style.fontFamily
    if (ff) usedFamilies.add(ff.split(',')[0].replace(/['"]/g, '').trim())
  })

  // Build CSS with Google Fonts imports
  const fontLinks = Array.from(usedFamilies)
    .filter(f => !['monospace', 'serif', 'sans-serif', 'Menlo', 'Consolas', 'Courier New'].includes(f))
    .map(f => `@import url('https://fonts.googleapis.com/css2?family=${f.replace(/ /g, '+')}:wght@300;400;500;600;700&display=swap');`)
    .join('\n')

  // Inline all stylesheets
  const styleSheets = Array.from(document.styleSheets)
  let inlinedCss = ''
  styleSheets.forEach(sheet => {
    try {
      const rules = Array.from(sheet.cssRules)
      rules.forEach(rule => { inlinedCss += rule.cssText + '\n' })
    } catch {}
  })

  const css = `${fontLinks}\n${inlinedCss}`
  const html = clone.outerHTML

  return { html, css }
}

// ─── Download Helpers ──────────────────────────────────────────────────────

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

export function copyBlobToClipboard(blob: Blob): Promise<void> {
  if (!navigator.clipboard?.write) {
    return Promise.reject(new Error('Clipboard API not supported'))
  }
  const item = new ClipboardItem({ [blob.type]: blob })
  return navigator.clipboard.write([item])
}

// ─── Utilities ─────────────────────────────────────────────────────────────

function dataUrlToBlob(dataUrl: string): Blob {
  const [header, data] = dataUrl.split(',')
  const mimeMatch = header.match(/:(.*?);/)
  const mime = mimeMatch ? mimeMatch[1] : 'image/png'
  const binaryStr = atob(data)
  const bytes = new Uint8Array(binaryStr.length)
  for (let i = 0; i < binaryStr.length; i++) {
    bytes[i] = binaryStr.charCodeAt(i)
  }
  return new Blob([bytes], { type: mime })
}

export function getExportFilename(format: string, title = 'carbon'): string {
  const sanitized = title.replace(/[^a-z0-9-_]/gi, '-').toLowerCase() || 'carbon'
  const timestamp = new Date().toISOString().slice(0, 10)
  return `${sanitized}-${timestamp}.${format}`
}

// ─── Image Size Calculator ─────────────────────────────────────────────────

export function getElementDimensions(element: HTMLElement): { width: number; height: number } {
  const rect = element.getBoundingClientRect()
  return { width: Math.ceil(rect.width), height: Math.ceil(rect.height) }
}
