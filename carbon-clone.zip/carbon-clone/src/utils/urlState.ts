/**
 * URL State Serialization
 * Encodes the full Carbon editor state into a compressed base64url hash
 * so any configuration can be shared as a permalink.
 */

import type { AppState } from '@/types'

// ─── Compress / Decompress ────────────────────────────────────────────────

async function compress(str: string): Promise<string> {
  const stream = new CompressionStream('deflate-raw')
  const writer = stream.writable.getWriter()
  const encoder = new TextEncoder()
  writer.write(encoder.encode(str))
  writer.close()
  const chunks: Uint8Array[] = []
  const reader = stream.readable.getReader()
  while (true) {
    const { value, done } = await reader.read()
    if (done) break
    chunks.push(value)
  }
  const totalLength = chunks.reduce((acc, c) => acc + c.length, 0)
  const merged = new Uint8Array(totalLength)
  let offset = 0
  for (const chunk of chunks) {
    merged.set(chunk, offset)
    offset += chunk.length
  }
  return btoa(String.fromCharCode(...merged))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

async function decompress(encoded: string): Promise<string> {
  const base64 = encoded.replace(/-/g, '+').replace(/_/g, '/')
  const binary = atob(base64)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i)

  const stream = new DecompressionStream('deflate-raw')
  const writer = stream.writable.getWriter()
  writer.write(bytes)
  writer.close()
  const chunks: Uint8Array[] = []
  const reader = stream.readable.getReader()
  while (true) {
    const { value, done } = await reader.read()
    if (done) break
    chunks.push(value)
  }
  const merged = new Uint8Array(chunks.reduce((a, c) => a + c.length, 0))
  let offset = 0
  for (const chunk of chunks) { merged.set(chunk, offset); offset += chunk.length }
  return new TextDecoder().decode(merged)
}

// ─── Shareable fields (exclude transient UI state) ────────────────────────

type ShareableState = Pick<AppState,
  | 'editor'
  | 'background'
  | 'shadow'
  | 'window'
  | 'padding'
  | 'watermark'
  | 'borderRadius'
  | 'width'
>

function extractShareable(state: AppState): ShareableState {
  return {
    editor: state.editor,
    background: state.background,
    shadow: state.shadow,
    window: state.window,
    padding: state.padding,
    watermark: state.watermark,
    borderRadius: state.borderRadius,
    width: state.width,
  }
}

// ─── Public API ───────────────────────────────────────────────────────────

export async function encodeStateToUrl(state: AppState): Promise<string> {
  const shareable = extractShareable(state)
  const json = JSON.stringify(shareable)
  const compressed = await compress(json)
  const url = new URL(window.location.href)
  url.hash = `state=${compressed}`
  return url.toString()
}

export async function decodeStateFromUrl(url: string): Promise<Partial<AppState> | null> {
  try {
    const hash = new URL(url).hash
    const match = hash.match(/state=([^&]+)/)
    if (!match) return null
    const json = await decompress(match[1])
    return JSON.parse(json) as Partial<AppState>
  } catch {
    return null
  }
}

export async function getSharedStateFromCurrentUrl(): Promise<Partial<AppState> | null> {
  return decodeStateFromUrl(window.location.href)
}

export async function copyShareableUrl(state: AppState): Promise<string> {
  const url = await encodeStateToUrl(state)
  await navigator.clipboard.writeText(url)
  return url
}
