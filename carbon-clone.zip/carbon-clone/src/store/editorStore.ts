import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import type {
  AppState,
  EditorConfig,
  BackgroundConfig,
  ShadowConfig,
  WindowConfig,
  PaddingConfig,
  WatermarkConfig,
  ExportOptions,
} from '@/types'

// ─── Default Values ────────────────────────────────────────────────────────

const DEFAULT_CODE = `async function fetchUserProfile(userId: string) {
  const response = await fetch(\`/api/users/\${userId}\`, {
    headers: { 
      'Authorization': \`Bearer \${getToken()}\`,
      'Content-Type': 'application/json',
    },
  })

  if (!response.ok) {
    throw new Error(\`HTTP \${response.status}: \${response.statusText}\`)
  }

  const data = await response.json()
  return {
    id: data.id,
    name: data.display_name,
    avatar: data.avatar_url,
    createdAt: new Date(data.created_at),
  }
}`

const DEFAULT_EDITOR: EditorConfig = {
  code: DEFAULT_CODE,
  language: 'typescript',
  theme: 'github-dark',
  fontFamily: 'JetBrains Mono',
  fontSize: 14,
  lineHeight: 1.6,
  tabSize: 2,
  showLineNumbers: true,
  firstLineNumber: 1,
  lineNumberStart: 1,
  showWhiteSpace: false,
  wrapLines: false,
}

const DEFAULT_BACKGROUND: BackgroundConfig = {
  type: 'gradient',
  solid: '#1a1a2e',
  gradient: {
    angle: 135,
    stops: [
      { color: '#0f0c29', position: 0 },
      { color: '#302b63', position: 50 },
      { color: '#24243e', position: 100 },
    ],
  },
  imageUrl: '',
  blur: 0,
}

const DEFAULT_SHADOW: ShadowConfig = {
  enabled: true,
  x: 0,
  y: 20,
  blur: 68,
  spread: 0,
  color: 'rgba(0,0,0,0.55)',
  inset: false,
}

const DEFAULT_WINDOW: WindowConfig = {
  style: 'mac',
  buttonStyle: 'colorful',
  title: '',
  showTitle: false,
  showLine: true,
}

const DEFAULT_PADDING: PaddingConfig = {
  top: 56,
  right: 56,
  bottom: 56,
  left: 56,
  linked: true,
}

const DEFAULT_WATERMARK: WatermarkConfig = {
  enabled: false,
  text: 'carbon.now.sh',
  position: 'bottom-right',
  opacity: 0.4,
}

// ─── Store Interface ───────────────────────────────────────────────────────

interface EditorStore extends AppState {
  // Editor actions
  setCode: (code: string) => void
  setLanguage: (language: string) => void
  setTheme: (theme: string) => void
  setFontFamily: (family: string) => void
  setFontSize: (size: number) => void
  setLineHeight: (lh: number) => void
  setTabSize: (size: number) => void
  toggleLineNumbers: () => void
  setFirstLineNumber: (n: number) => void
  toggleWrapLines: () => void
  toggleWhiteSpace: () => void

  // Background actions
  setBackgroundType: (type: BackgroundConfig['type']) => void
  setBackgroundSolid: (color: string) => void
  setGradientAngle: (angle: number) => void
  setGradientStops: (stops: BackgroundConfig['gradient']['stops']) => void
  setBackgroundImage: (url: string) => void
  setBackgroundBlur: (blur: number) => void

  // Shadow actions
  setShadow: (shadow: Partial<ShadowConfig>) => void
  toggleShadow: () => void

  // Window actions
  setWindowStyle: (style: WindowConfig['style']) => void
  setWindowButtonStyle: (style: WindowConfig['buttonStyle']) => void
  setWindowTitle: (title: string) => void
  toggleWindowTitle: () => void

  // Padding actions
  setPadding: (padding: Partial<PaddingConfig>) => void
  setPaddingAll: (value: number) => void

  // Watermark actions
  setWatermark: (wm: Partial<WatermarkConfig>) => void
  toggleWatermark: () => void

  // Global
  setBorderRadius: (r: number) => void
  setWidth: (w: number | 'auto') => void
  setActivePanel: (panel: string) => void

  // Export state
  setExporting: (v: boolean) => void
  setExportProgress: (p: number) => void
  setExportError: (e: string | null) => void

  // Export options (last used)
  exportOptions: ExportOptions
  setExportOptions: (opts: Partial<ExportOptions>) => void

  // Presets
  resetToDefault: () => void
  applyPreset: (config: Partial<AppState>) => void
}

// ─── Store ─────────────────────────────────────────────────────────────────

export const useEditorStore = create<EditorStore>()(
  persist(
    (set, _get) => ({
      // State
      editor: DEFAULT_EDITOR,
      background: DEFAULT_BACKGROUND,
      shadow: DEFAULT_SHADOW,
      window: DEFAULT_WINDOW,
      padding: DEFAULT_PADDING,
      watermark: DEFAULT_WATERMARK,
      borderRadius: 12,
      width: 'auto',
      isExporting: false,
      exportProgress: 0,
      exportError: null,
      activePanel: 'editor',
      exportOptions: {
        format: 'png',
        quality: 'high',
        scale: 2,
        method: 'html-to-image',
      },

      // ── Editor ──
      setCode: (code) => set((s) => ({ editor: { ...s.editor, code } })),
      setLanguage: (language) => set((s) => ({ editor: { ...s.editor, language } })),
      setTheme: (theme) => set((s) => ({ editor: { ...s.editor, theme } })),
      setFontFamily: (fontFamily) => set((s) => ({ editor: { ...s.editor, fontFamily } })),
      setFontSize: (fontSize) => set((s) => ({ editor: { ...s.editor, fontSize } })),
      setLineHeight: (lineHeight) => set((s) => ({ editor: { ...s.editor, lineHeight } })),
      setTabSize: (tabSize) => set((s) => ({ editor: { ...s.editor, tabSize } })),
      toggleLineNumbers: () =>
        set((s) => ({ editor: { ...s.editor, showLineNumbers: !s.editor.showLineNumbers } })),
      setFirstLineNumber: (firstLineNumber) =>
        set((s) => ({ editor: { ...s.editor, firstLineNumber } })),
      toggleWrapLines: () =>
        set((s) => ({ editor: { ...s.editor, wrapLines: !s.editor.wrapLines } })),
      toggleWhiteSpace: () =>
        set((s) => ({ editor: { ...s.editor, showWhiteSpace: !s.editor.showWhiteSpace } })),

      // ── Background ──
      setBackgroundType: (type) => set((s) => ({ background: { ...s.background, type } })),
      setBackgroundSolid: (solid) => set((s) => ({ background: { ...s.background, solid } })),
      setGradientAngle: (angle) =>
        set((s) => ({
          background: {
            ...s.background,
            gradient: { ...s.background.gradient, angle },
          },
        })),
      setGradientStops: (stops) =>
        set((s) => ({
          background: {
            ...s.background,
            gradient: { ...s.background.gradient, stops },
          },
        })),
      setBackgroundImage: (imageUrl) =>
        set((s) => ({ background: { ...s.background, imageUrl } })),
      setBackgroundBlur: (blur) => set((s) => ({ background: { ...s.background, blur } })),

      // ── Shadow ──
      setShadow: (shadow) => set((s) => ({ shadow: { ...s.shadow, ...shadow } })),
      toggleShadow: () => set((s) => ({ shadow: { ...s.shadow, enabled: !s.shadow.enabled } })),

      // ── Window ──
      setWindowStyle: (style) => set((s) => ({ window: { ...s.window, style } })),
      setWindowButtonStyle: (buttonStyle) =>
        set((s) => ({ window: { ...s.window, buttonStyle } })),
      setWindowTitle: (title) => set((s) => ({ window: { ...s.window, title } })),
      toggleWindowTitle: () =>
        set((s) => ({ window: { ...s.window, showTitle: !s.window.showTitle } })),

      // ── Padding ──
      setPadding: (padding) => set((s) => ({ padding: { ...s.padding, ...padding } })),
      setPaddingAll: (value) =>
        set((s) => ({
          padding: { ...s.padding, top: value, right: value, bottom: value, left: value },
        })),

      // ── Watermark ──
      setWatermark: (wm) => set((s) => ({ watermark: { ...s.watermark, ...wm } })),
      toggleWatermark: () =>
        set((s) => ({ watermark: { ...s.watermark, enabled: !s.watermark.enabled } })),

      // ── Global ──
      setBorderRadius: (borderRadius) => set({ borderRadius }),
      setWidth: (width) => set({ width }),
      setActivePanel: (activePanel) => set({ activePanel }),

      // ── Export state ──
      setExporting: (isExporting) => set({ isExporting }),
      setExportProgress: (exportProgress) => set({ exportProgress }),
      setExportError: (exportError) => set({ exportError }),
      setExportOptions: (opts) => set((s) => ({ exportOptions: { ...s.exportOptions, ...opts } })),

      // ── Presets ──
      resetToDefault: () =>
        set({
          editor: DEFAULT_EDITOR,
          background: DEFAULT_BACKGROUND,
          shadow: DEFAULT_SHADOW,
          window: DEFAULT_WINDOW,
          padding: DEFAULT_PADDING,
          watermark: DEFAULT_WATERMARK,
          borderRadius: 12,
          width: 'auto',
        }),

      applyPreset: (config) =>
        set((s) => ({
          editor: config.editor ? { ...s.editor, ...config.editor } : s.editor,
          background: config.background ? { ...s.background, ...config.background } : s.background,
          shadow: config.shadow ? { ...s.shadow, ...config.shadow } : s.shadow,
          window: config.window ? { ...s.window, ...config.window } : s.window,
          padding: config.padding ? { ...s.padding, ...config.padding } : s.padding,
          borderRadius: config.borderRadius ?? s.borderRadius,
        })),
    }),
    {
      name: 'carbon-editor-state',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        editor: state.editor,
        background: state.background,
        shadow: state.shadow,
        window: state.window,
        padding: state.padding,
        watermark: state.watermark,
        borderRadius: state.borderRadius,
        width: state.width,
        exportOptions: state.exportOptions,
      }),
    }
  )
)

// ─── Selector Hooks ────────────────────────────────────────────────────────

export const useEditorConfig = () => useEditorStore((s) => s.editor)
export const useBackgroundConfig = () => useEditorStore((s) => s.background)
export const useShadowConfig = () => useEditorStore((s) => s.shadow)
export const useWindowConfig = () => useEditorStore((s) => s.window)
export const usePaddingConfig = () => useEditorStore((s) => s.padding)
export const useWatermarkConfig = () => useEditorStore((s) => s.watermark)
export const useExportOptions = () => useEditorStore((s) => s.exportOptions)
