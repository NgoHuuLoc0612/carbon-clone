import { useState, useEffect, useRef, useCallback } from 'react'
import type { CodeAnalysis } from '@/types'

// ─── Tree-Sitter WASM Paths ────────────────────────────────────────────────
// These need to be in public/wasm/ directory
// Download from: https://github.com/tree-sitter/tree-sitter/releases

const WASM_BASE = '/wasm'

const LANG_WASM_MAP: Record<string, string> = {
  javascript: `${WASM_BASE}/tree-sitter-javascript.wasm`,
  typescript: `${WASM_BASE}/tree-sitter-typescript.wasm`,
  tsx: `${WASM_BASE}/tree-sitter-tsx.wasm`,
  jsx: `${WASM_BASE}/tree-sitter-javascript.wasm`,  // reuse JS grammar
  python: `${WASM_BASE}/tree-sitter-python.wasm`,
  rust: `${WASM_BASE}/tree-sitter-rust.wasm`,
  go: `${WASM_BASE}/tree-sitter-go.wasm`,
  cpp: `${WASM_BASE}/tree-sitter-cpp.wasm`,
  c: `${WASM_BASE}/tree-sitter-c.wasm`,
  java: `${WASM_BASE}/tree-sitter-java.wasm`,
  csharp: `${WASM_BASE}/tree-sitter-c_sharp.wasm`,
  css: `${WASM_BASE}/tree-sitter-css.wasm`,
  json: `${WASM_BASE}/tree-sitter-json.wasm`,
  php: `${WASM_BASE}/tree-sitter-php.wasm`,
  scala: `${WASM_BASE}/tree-sitter-scala.wasm`,
  julia: `${WASM_BASE}/tree-sitter-julia.wasm`,
  ocaml: `${WASM_BASE}/tree-sitter-ocaml.wasm`,
  codeql: `${WASM_BASE}/tree-sitter-ql.wasm`,
}

// ─── Types ─────────────────────────────────────────────────────────────────

interface UseTreeSitterReturn {
  analysis: CodeAnalysis | null
  ready: boolean
  loading: boolean
  parseCode: (code: string, language: string) => Promise<void>
  getSyntaxErrors: () => Array<{ line: number; col: number; message: string }>
  getComplexity: (code: string, language: string) => number
}

interface ParsedNode {
  type: string
  text?: string
  startPosition: { row: number; column: number }
  endPosition: { row: number; column: number }
  hasError: boolean
  children: ParsedNode[]
  namedChildren: ParsedNode[]
}

// ─── Complexity Calculator ─────────────────────────────────────────────────

const COMPLEXITY_NODE_TYPES = new Set([
  // JS/TS/JSX/TSX
  'if_statement', 'while_statement', 'for_statement', 'for_in_statement',
  'for_of_statement', 'catch_clause', 'conditional_expression',
  'logical_and_expression', 'logical_or_expression', 'switch_case',
  'function_declaration', 'arrow_function', 'method_definition',
  'function_expression', 'async_function', 'generator_function',
  // Python
  'elif_clause', 'except_clause', 'with_statement', 'lambda',
  // Rust
  'match_arm', 'if_let_expression', 'while_let_expression', 'closure_expression',
  'loop_expression',
  // Go
  'select_statement', 'type_switch_statement', 'go_statement',
  // C/C++
  'do_statement', 'case_statement', 'ternary_expression',
  // Java/Scala/C#
  'enhanced_for_statement', 'try_statement', 'synchronized_statement',
  'lambda_expression', 'method_invocation',
  // PHP
  'foreach_statement', 'match_expression',
  // Scala
  'match', 'case_clause', 'for_expression', 'function_definition',
  // Julia
  'for_binding', 'try_catch_finally',
  // OCaml
  'match_case', 'fun_expression', 'let_binding',
])

function calculateComplexity(node: any, depth = 0): number {
  if (!node) return 0
  let complexity = COMPLEXITY_NODE_TYPES.has(node.type) ? 1 : 0
  for (let i = 0; i < node.childCount; i++) {
    complexity += calculateComplexity(node.child(i), depth + 1)
  }
  return complexity
}

// ─── Symbol Extractor ──────────────────────────────────────────────────────

function extractSymbols(node: any): CodeAnalysis['symbols'] {
  const symbols: CodeAnalysis['symbols'] = []
  const symbolTypes = new Set([
    // JS/TS
    'function_declaration', 'method_definition', 'class_declaration',
    'variable_declarator', 'lexical_declaration', 'export_statement',
    'interface_declaration', 'type_alias_declaration', 'enum_declaration',
    // Python
    'function_definition', 'class_definition', 'decorated_definition',
    // Rust
    'function_item', 'struct_item', 'enum_item', 'trait_item', 'impl_item', 'mod_item',
    // Go
    'function_declaration', 'method_declaration', 'type_declaration', 'const_declaration',
    // C/C++
    'function_definition', 'struct_specifier', 'class_specifier', 'namespace_definition',
    // Java
    'method_declaration', 'class_declaration', 'interface_declaration', 'enum_declaration',
    // C#
    'method_declaration', 'class_declaration', 'namespace_declaration', 'property_declaration',
    // PHP
    'function_definition', 'method_declaration', 'class_declaration',
    // Scala
    'function_definition', 'class_definition', 'object_definition', 'trait_definition', 'val_definition',
    // Julia
    'function_definition', 'struct_definition', 'abstract_definition',
    // OCaml
    'let_binding', 'type_definition', 'module_definition', 'value_specification',
    // CodeQL
    'predicate', 'class', 'module',
  ])

  function traverse(n: any) {
    if (!n) return
    if (symbolTypes.has(n.type)) {
      const nameNode = n.childForFieldName?.('name') || n.childForFieldName?.('id') || n.children?.[1]
      if (nameNode) {
        symbols.push({
          name: nameNode.text ?? '',
          type: n.type.replace(/_declaration|_definition|_item|_specifier/, ''),
          row: n.startPosition.row,
          col: n.startPosition.column,
        })
      }
    }
    for (let i = 0; i < n.childCount; i++) {
      traverse(n.child(i))
    }
  }
  traverse(node)
  return symbols
}

// ─── Error Extractor ───────────────────────────────────────────────────────

function extractErrors(node: any): CodeAnalysis['errors'] {
  const errors: CodeAnalysis['errors'] = []

  function traverse(n: any) {
    if (!n) return
    if (n.type === 'ERROR' || n.isMissing) {
      errors.push({
        startRow: n.startPosition.row,
        startCol: n.startPosition.column,
        endRow: n.endPosition.row,
        endCol: n.endPosition.column,
        message: n.type === 'ERROR' ? 'Syntax error' : `Missing ${n.type}`,
      })
    }
    for (let i = 0; i < n.childCount; i++) {
      traverse(n.child(i))
    }
  }
  traverse(node)
  return errors
}

// ─── Hook ──────────────────────────────────────────────────────────────────

export function useTreeSitter(): UseTreeSitterReturn {
  const [ready, setReady] = useState(false)
  const [loading, setLoading] = useState(true)
  const [analysis, setAnalysis] = useState<CodeAnalysis | null>(null)
  const parserRef = useRef<any>(null)
  const loadedLangsRef = useRef<Map<string, any>>(new Map())
  const currentLangRef = useRef<string>('')
  const errorsRef = useRef<CodeAnalysis['errors']>([])

  // Initialize Tree-sitter
  useEffect(() => {
    let cancelled = false

    async function initTreeSitter() {
      try {
        const { Parser } = await import('web-tree-sitter')
        await Parser.init({
          locateFile(path: string) {
            if (path.endsWith('.wasm')) {
              return `${WASM_BASE}/tree-sitter.wasm`
            }
            return path
          },
        })
        if (!cancelled) {
          parserRef.current = new Parser()
          setReady(true)
          setLoading(false)
        }
      } catch (err) {
        console.warn('Tree-sitter init failed:', err)
        if (!cancelled) {
          setLoading(false)
        }
      }
    }

    initTreeSitter()
    return () => { cancelled = true }
  }, [])

  // Load language WASM
  const loadLanguage = useCallback(async (language: string) => {
    if (!parserRef.current || !ready) return null
    if (loadedLangsRef.current.has(language)) {
      return loadedLangsRef.current.get(language)!
    }

    const wasmPath = LANG_WASM_MAP[language]
    if (!wasmPath) return null

    try {
      const { Parser } = await import('web-tree-sitter')
      const lang = await Parser.Language.load(wasmPath)
      loadedLangsRef.current.set(language, lang)
      return lang
    } catch {
      return null
    }
  }, [ready])

  // Parse code
  const parseCode = useCallback(async (code: string, language: string) => {
    if (!parserRef.current || !ready) {
      // Fallback analysis without tree-sitter
      setAnalysis({
        errors: [],
        symbols: [],
        lineCount: code.split('\n').length,
        charCount: code.length,
        complexity: 0,
      })
      return
    }

    const lang = await loadLanguage(language)
    if (!lang) {
      setAnalysis({
        errors: [],
        symbols: [],
        lineCount: code.split('\n').length,
        charCount: code.length,
        complexity: 0,
      })
      return
    }

    try {
      parserRef.current.setLanguage(lang)
      const tree = parserRef.current.parse(code)
      const root = tree.rootNode

      const errors = extractErrors(root)
      const symbols = extractSymbols(root)
      const complexity = calculateComplexity(root)

      errorsRef.current = errors
      currentLangRef.current = language

      setAnalysis({
        errors,
        symbols,
        lineCount: code.split('\n').length,
        charCount: code.length,
        complexity,
      })

      tree.delete()
    } catch (err) {
      console.warn('Parse error:', err)
    }
  }, [ready, loadLanguage])

  const getSyntaxErrors = useCallback(() => {
    return errorsRef.current.map(e => ({
      line: e.startRow + 1,
      col: e.startCol + 1,
      message: e.message,
    }))
  }, [])

  // Lightweight complexity calculation (no tree-sitter required)
  const getComplexity = useCallback((code: string, _language: string): number => {
    if (analysis) return analysis.complexity
    // Regex-based fallback
    const patterns = [
      /\bif\b/g, /\belse\b/g, /\bwhile\b/g, /\bfor\b/g,
      /\bcatch\b/g, /\bcase\b/g, /\?\s*.*\s*:/g,
      /&&|\|\|/g, /\bfunction\b|\=>/g,
    ]
    return patterns.reduce((acc, p) => acc + (code.match(p)?.length ?? 0), 1)
  }, [analysis])

  return { analysis, ready, loading, parseCode, getSyntaxErrors, getComplexity }
}
