import { useState, useEffect, useRef, useCallback } from 'react'
import type { Highlighter, BundledLanguage, BundledTheme } from 'shiki'
import type { HighlightedCode } from '@/types'

// ─── Available Themes ──────────────────────────────────────────────────────

export const SHIKI_THEMES: Array<{ id: BundledTheme; name: string; type: 'dark' | 'light'; preview: string }> = [
  { id: 'github-dark', name: 'GitHub Dark', type: 'dark', preview: '#0d1117' },
  { id: 'github-dark-dimmed', name: 'GitHub Dark Dimmed', type: 'dark', preview: '#22272e' },
  { id: 'github-light', name: 'GitHub Light', type: 'light', preview: '#ffffff' },
  { id: 'monokai', name: 'Monokai', type: 'dark', preview: '#272822' },
  { id: 'night-owl', name: 'Night Owl', type: 'dark', preview: '#011627' },
  { id: 'dracula', name: 'Dracula', type: 'dark', preview: '#282a36' },
  { id: 'dracula-soft', name: 'Dracula Soft', type: 'dark', preview: '#22212c' },
  { id: 'one-dark-pro', name: 'One Dark Pro', type: 'dark', preview: '#282c34' },
  { id: 'synthwave-84', name: 'Synthwave \'84', type: 'dark', preview: '#2b213a' },
  { id: 'tokyo-night', name: 'Tokyo Night', type: 'dark', preview: '#1a1b26' },
  { id: 'catppuccin-mocha', name: 'Catppuccin Mocha', type: 'dark', preview: '#1e1e2e' },
  { id: 'catppuccin-macchiato', name: 'Catppuccin Macchiato', type: 'dark', preview: '#24273a' },
  { id: 'catppuccin-frappe', name: 'Catppuccin Frappé', type: 'dark', preview: '#303446' },
  { id: 'catppuccin-latte', name: 'Catppuccin Latte', type: 'light', preview: '#eff1f5' },
  { id: 'solarized-dark', name: 'Solarized Dark', type: 'dark', preview: '#002b36' },
  { id: 'solarized-light', name: 'Solarized Light', type: 'light', preview: '#fdf6e3' },
  { id: 'material-theme', name: 'Material Theme', type: 'dark', preview: '#212121' },
  { id: 'material-theme-darker', name: 'Material Darker', type: 'dark', preview: '#212121' },
  { id: 'material-theme-ocean', name: 'Material Ocean', type: 'dark', preview: '#0f111a' },
  { id: 'material-theme-palenight', name: 'Material Palenight', type: 'dark', preview: '#292d3e' },
  { id: 'nord', name: 'Nord', type: 'dark', preview: '#2e3440' },
  { id: 'aurora-x', name: 'Aurora X', type: 'dark', preview: '#07090f' },
  { id: 'ayu-dark', name: 'Ayu Dark', type: 'dark', preview: '#0a0e14' },
  { id: 'slack-dark', name: 'Slack Dark', type: 'dark', preview: '#222529' },
  { id: 'poimandres', name: 'Poimandres', type: 'dark', preview: '#1b1e28' },
  { id: 'rose-pine', name: 'Rosé Pine', type: 'dark', preview: '#191724' },
  { id: 'rose-pine-moon', name: 'Rosé Pine Moon', type: 'dark', preview: '#232136' },
  { id: 'vitesse-dark', name: 'Vitesse Dark', type: 'dark', preview: '#121212' },
  { id: 'vitesse-light', name: 'Vitesse Light', type: 'light', preview: '#ffffff' },
  { id: 'vesper', name: 'Vesper', type: 'dark', preview: '#101010' },
]

// ─── Available Languages ───────────────────────────────────────────────────

export const SHIKI_LANGUAGES: Array<{ id: string; name: string; aliases?: string[] }> = [
  // ── Tree-sitter backed (AST parsing + highlight) ──────────────────────────
  { id: 'javascript', name: 'JavaScript', aliases: ['js'] },
  { id: 'typescript', name: 'TypeScript', aliases: ['ts'] },
  { id: 'jsx',        name: 'JSX' },
  { id: 'tsx',        name: 'TSX' },
  { id: 'python',     name: 'Python',     aliases: ['py'] },
  { id: 'rust',       name: 'Rust',       aliases: ['rs'] },
  { id: 'go',         name: 'Go',         aliases: ['golang'] },
  { id: 'cpp',        name: 'C++',        aliases: ['c++'] },
  { id: 'c',          name: 'C' },
  { id: 'java',       name: 'Java' },
  { id: 'csharp',     name: 'C#',         aliases: ['cs'] },
  { id: 'php',        name: 'PHP' },
  { id: 'scala',      name: 'Scala' },
  { id: 'julia',      name: 'Julia' },
  { id: 'ocaml',      name: 'OCaml',      aliases: ['ml'] },
  { id: 'css',        name: 'CSS' },
  { id: 'json',       name: 'JSON' },
  { id: 'codeql',     name: 'CodeQL',     aliases: ['ql'] },
  // ── Highlight only (no tree-sitter WASM) ─────────────────────────────────
  { id: 'html',       name: 'HTML' },
  { id: 'bash',       name: 'Bash/Shell', aliases: ['sh', 'shell'] },
  { id: 'sql',        name: 'SQL' },
  { id: 'graphql',    name: 'GraphQL',    aliases: ['gql'] },
  { id: 'yaml',       name: 'YAML',       aliases: ['yml'] },
  { id: 'toml',       name: 'TOML' },
  { id: 'markdown',   name: 'Markdown',   aliases: ['md'] },
  { id: 'scss',       name: 'SCSS' },
  { id: 'kotlin',     name: 'Kotlin',     aliases: ['kt'] },
  { id: 'swift',      name: 'Swift' },
  { id: 'ruby',       name: 'Ruby',       aliases: ['rb'] },
  { id: 'lua',        name: 'Lua' },
  { id: 'haskell',    name: 'Haskell',    aliases: ['hs'] },
  { id: 'elixir',     name: 'Elixir',     aliases: ['ex'] },
  { id: 'erlang',     name: 'Erlang' },
  { id: 'clojure',    name: 'Clojure',    aliases: ['clj'] },
  { id: 'r',          name: 'R' },
  { id: 'dart',       name: 'Dart' },
  { id: 'powershell', name: 'PowerShell', aliases: ['ps1'] },
  { id: 'dockerfile', name: 'Dockerfile' },
  { id: 'terraform',  name: 'Terraform',  aliases: ['tf'] },
  { id: 'vue',        name: 'Vue' },
  { id: 'svelte',     name: 'Svelte' },
  { id: 'groovy',     name: 'Groovy' },
  { id: 'proto',      name: 'Protocol Buffers', aliases: ['protobuf'] },
  { id: 'nginx',      name: 'Nginx' },
  { id: 'diff',       name: 'Diff' },
  { id: 'text',       name: 'Plain Text' },
]

// ─── Hook ──────────────────────────────────────────────────────────────────

interface UseShikiOptions {
  code: string
  language: string
  theme: string
}

interface UseShikiReturn {
  highlighted: HighlightedCode | null
  loading: boolean
  error: string | null
  highlighter: Highlighter | null
  codeToHtml: (code: string, lang: string, theme: string) => string
  codeToSvg: (code: string, lang: string, theme: string) => string
}

export function useShiki({ code, language, theme }: UseShikiOptions): UseShikiReturn {
  const [highlighted, setHighlighted] = useState<HighlightedCode | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const highlighterRef = useRef<Highlighter | null>(null)
  const loadedThemesRef = useRef<Set<string>>(new Set())
  const loadedLangsRef = useRef<Set<string>>(new Set())

  // Initialize the highlighter
  useEffect(() => {
    let cancelled = false

    async function init() {
      try {
        const { createHighlighter } = await import('shiki')

        if (!highlighterRef.current) {
          const hl = await createHighlighter({
            themes: [theme as BundledTheme],
            langs: [language as BundledLanguage],
          })
          if (!cancelled) {
            highlighterRef.current = hl
            loadedThemesRef.current.add(theme)
            loadedLangsRef.current.add(language)
            setLoading(false)
          }
        }
      } catch (err) {
        if (!cancelled) {
          setError(String(err))
          setLoading(false)
        }
      }
    }

    init()
    return () => { cancelled = true }
  }, [])

  // Load missing theme/language and re-highlight
  useEffect(() => {
    if (!highlighterRef.current) return

    let cancelled = false

    async function ensureAndHighlight() {
      const hl = highlighterRef.current!

      try {
        // Load theme if needed
        if (!loadedThemesRef.current.has(theme)) {
          await hl.loadTheme(theme as BundledTheme)
          loadedThemesRef.current.add(theme)
        }

        // Load language if needed
        const langId = language as BundledLanguage
        if (!loadedLangsRef.current.has(language)) {
          await hl.loadLanguage(langId)
          loadedLangsRef.current.add(language)
        }

        if (cancelled) return

        const html = hl.codeToHtml(code, {
          lang: langId,
          theme: theme as BundledTheme,
        })

        // Extract background/foreground colors from theme
        const themeObj = hl.getTheme(theme as BundledTheme)
        const bg = themeObj.bg ?? '#0d1117'
        const fg = themeObj.fg ?? '#e6edf3'

        setHighlighted({ html, tokens: [], bg, fg, themeName: theme })
      } catch (err) {
        if (!cancelled) {
          setError(String(err))
        }
      }
    }

    ensureAndHighlight()
    return () => { cancelled = true }
  }, [code, language, theme, loading])

  const codeToHtml = useCallback((c: string, lang: string, t: string): string => {
    if (!highlighterRef.current) return `<pre>${c}</pre>`
    try {
      return highlighterRef.current.codeToHtml(c, {
        lang: lang as BundledLanguage,
        theme: t as BundledTheme,
      })
    } catch {
      return `<pre>${c}</pre>`
    }
  }, [loading])

  const codeToSvg = useCallback((c: string, lang: string, t: string): string => {
    if (!highlighterRef.current) return ''
    try {
      // Use getSVGRenderer from shiki if available, otherwise construct basic SVG
      const tokens = highlighterRef.current.codeToTokensBase(c, {
        lang: lang as BundledLanguage,
        theme: t as BundledTheme,
      })
      const themeObj = highlighterRef.current.getTheme(t as BundledTheme)
      const bg = themeObj.bg ?? '#0d1117'

      const lineHeight = 20
      const fontSize = 14
      const paddingX = 20
      const paddingY = 16
      const charWidth = fontSize * 0.6

      const lines = tokens
      const maxLineLen = Math.max(...lines.map((l) => l.reduce((a, tk) => a + tk.content.length, 0)))
      const svgWidth = maxLineLen * charWidth + paddingX * 2
      const svgHeight = lines.length * lineHeight + paddingY * 2

      const svgLines = lines.map((line, i) => {
        const y = paddingY + i * lineHeight + lineHeight * 0.75
        let x = paddingX
        const spans = line.map((token) => {
          const color = (token as any).color ?? '#ffffff'
          const span = `<text x="${x}" y="${y}" fill="${color}" font-family="monospace" font-size="${fontSize}">${token.content.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</text>`
          x += token.content.length * charWidth
          return span
        })
        return spans.join('')
      })

      return `<svg xmlns="http://www.w3.org/2000/svg" width="${svgWidth}" height="${svgHeight}">
  <rect width="${svgWidth}" height="${svgHeight}" fill="${bg}"/>
  ${svgLines.join('\n  ')}
</svg>`
    } catch {
      return ''
    }
  }, [loading])

  return { highlighted, loading, error, highlighter: highlighterRef.current, codeToHtml, codeToSvg }
}
