import { useRef, useCallback, useState } from 'react'

interface Snapshot {
  code: string
  timestamp: number
  label?: string
}

interface UseCodeHistoryReturn {
  snapshots: Snapshot[]
  currentIndex: number
  canUndo: boolean
  canRedo: boolean
  pushSnapshot: (code: string, label?: string) => void
  undo: () => string | null
  redo: () => string | null
  jumpTo: (index: number) => string
  clearHistory: () => void
  getDiff: (indexA: number, indexB: number) => { old: string; new: string }
}

const MAX_HISTORY = 50

export function useCodeHistory(initialCode: string): UseCodeHistoryReturn {
  const [snapshots, setSnapshots] = useState<Snapshot[]>([
    { code: initialCode, timestamp: Date.now(), label: 'Initial' }
  ])
  const [currentIndex, setCurrentIndex] = useState(0)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const pushSnapshot = useCallback((code: string, label?: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      setSnapshots(prev => {
        // If we're not at the end, discard future history
        const base = prev.slice(0, currentIndex + 1)
        const last = base[base.length - 1]

        // Don't push duplicate
        if (last && last.code === code) return prev

        const next = [
          ...base,
          { code, timestamp: Date.now(), label }
        ].slice(-MAX_HISTORY)

        setCurrentIndex(next.length - 1)
        return next
      })
    }, 600)
  }, [currentIndex])

  const undo = useCallback((): string | null => {
    if (currentIndex <= 0) return null
    const newIndex = currentIndex - 1
    setCurrentIndex(newIndex)
    return snapshots[newIndex]?.code ?? null
  }, [currentIndex, snapshots])

  const redo = useCallback((): string | null => {
    if (currentIndex >= snapshots.length - 1) return null
    const newIndex = currentIndex + 1
    setCurrentIndex(newIndex)
    return snapshots[newIndex]?.code ?? null
  }, [currentIndex, snapshots])

  const jumpTo = useCallback((index: number): string => {
    const clamped = Math.max(0, Math.min(index, snapshots.length - 1))
    setCurrentIndex(clamped)
    return snapshots[clamped].code
  }, [snapshots])

  const clearHistory = useCallback(() => {
    const current = snapshots[currentIndex]
    setSnapshots([{ ...current, label: 'Cleared' }])
    setCurrentIndex(0)
  }, [snapshots, currentIndex])

  const getDiff = useCallback((indexA: number, indexB: number) => ({
    old: snapshots[indexA]?.code ?? '',
    new: snapshots[indexB]?.code ?? '',
  }), [snapshots])

  return {
    snapshots,
    currentIndex,
    canUndo: currentIndex > 0,
    canRedo: currentIndex < snapshots.length - 1,
    pushSnapshot,
    undo,
    redo,
    jumpTo,
    clearHistory,
    getDiff,
  }
}
