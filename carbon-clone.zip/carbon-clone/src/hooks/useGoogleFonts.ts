import { useState, useEffect, useCallback, useRef } from 'react'
import type { GoogleFont } from '@/types'

// ─── Monospace / Code Fonts ────────────────────────────────────────────────

export const CODING_FONTS: GoogleFont[] = [
  { family: 'JetBrains Mono', variants: ['regular', '500', '700', 'italic'], subsets: ['latin'], category: 'monospace' },
  { family: 'Fira Code', variants: ['300', 'regular', '500', '600', '700'], subsets: ['latin'], category: 'monospace' },
  { family: 'Source Code Pro', variants: ['regular', '500', '600', '700'], subsets: ['latin'], category: 'monospace' },
  { family: 'Cascadia Code', variants: ['regular', '600', '700'], subsets: ['latin'], category: 'monospace' },
  { family: 'Roboto Mono', variants: ['regular', '500', '700', 'italic'], subsets: ['latin'], category: 'monospace' },
  { family: 'Space Mono', variants: ['regular', '700', 'italic'], subsets: ['latin'], category: 'monospace' },
  { family: 'Inconsolata', variants: ['300', 'regular', '500', '700', '900'], subsets: ['latin'], category: 'monospace' },
  { family: 'IBM Plex Mono', variants: ['300', 'regular', '500', '600', '700', 'italic'], subsets: ['latin'], category: 'monospace' },
  { family: 'Courier Prime', variants: ['regular', '700', 'italic'], subsets: ['latin'], category: 'monospace' },
  { family: 'Hack', variants: ['regular', '700', 'italic'], subsets: ['latin'], category: 'monospace' },
  { family: 'Ubuntu Mono', variants: ['regular', '700', 'italic'], subsets: ['latin'], category: 'monospace' },
  { family: 'Overpass Mono', variants: ['300', 'regular', '600', '700'], subsets: ['latin'], category: 'monospace' },
  { family: 'Anonymous Pro', variants: ['regular', '700', 'italic'], subsets: ['latin'], category: 'monospace' },
  { family: 'Nanum Gothic Coding', variants: ['regular', '700'], subsets: ['korean', 'latin'], category: 'monospace' },
  { family: 'Martian Mono', variants: ['300', 'regular', '500', '600', '700', '800'], subsets: ['latin'], category: 'monospace' },
  { family: 'Azeret Mono', variants: ['300', 'regular', '500', '600', '700'], subsets: ['latin'], category: 'monospace' },
  { family: 'Chivo Mono', variants: ['300', 'regular', '500', '700'], subsets: ['latin'], category: 'monospace' },
  { family: 'Cutive Mono', variants: ['regular'], subsets: ['latin'], category: 'monospace' },
  { family: 'DM Mono', variants: ['300', 'regular', '500', 'italic'], subsets: ['latin'], category: 'monospace' },
  { family: 'Major Mono Display', variants: ['regular'], subsets: ['latin'], category: 'monospace' },
]

// ─── System Fonts ──────────────────────────────────────────────────────────

export const SYSTEM_FONTS: GoogleFont[] = [
  { family: 'monospace', variants: ['regular'], subsets: ['latin'], category: 'monospace' },
  { family: 'Menlo', variants: ['regular'], subsets: ['latin'], category: 'monospace' },
  { family: 'Consolas', variants: ['regular'], subsets: ['latin'], category: 'monospace' },
  { family: 'Courier New', variants: ['regular'], subsets: ['latin'], category: 'monospace' },
]

// ─── Hook ──────────────────────────────────────────────────────────────────

interface UseGoogleFontsReturn {
  fonts: GoogleFont[]
  loadedFonts: Set<string>
  loading: boolean
  error: string | null
  loadFont: (family: string, variants?: string[]) => Promise<void>
  searchFonts: (query: string) => GoogleFont[]
  getFontCSS: (family: string, size?: number, weight?: string) => React.CSSProperties
}

const GOOGLE_FONTS_API_KEY = import.meta.env.VITE_GOOGLE_FONTS_API_KEY || ''
const GOOGLE_FONTS_API_URL = 'https://www.googleapis.com/webfonts/v1/webfonts'

export function useGoogleFonts(): UseGoogleFontsReturn {
  const [fonts, setFonts] = useState<GoogleFont[]>(CODING_FONTS)
  const [loadedFonts] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const loadedLinksRef = useRef<Set<string>>(new Set())

  // Try to fetch full font list from Google Fonts API
  useEffect(() => {
    if (!GOOGLE_FONTS_API_KEY) {
      // Use pre-defined coding fonts list
      return
    }

    async function fetchFonts() {
      setLoading(true)
      try {
        const url = `${GOOGLE_FONTS_API_URL}?key=${GOOGLE_FONTS_API_KEY}&sort=popularity&capability=WOFF2`
        const res = await fetch(url)
        const data = await res.json()
        if (data.items) {
          const monoFonts: GoogleFont[] = data.items
            .filter((f: any) => f.category === 'monospace')
            .map((f: any) => ({
              family: f.family,
              variants: f.variants,
              subsets: f.subsets,
              category: f.category,
            }))
          // Merge with our curated list, dedup
          const all = [...CODING_FONTS]
          monoFonts.forEach((f: GoogleFont) => {
            if (!all.find(e => e.family === f.family)) {
              all.push(f)
            }
          })
          setFonts(all)
        }
      } catch (err) {
        // Gracefully fall back to pre-defined list
        console.warn('Google Fonts API fetch failed:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchFonts()
  }, [])

  // Load a specific font via <link> injection
  const loadFont = useCallback(async (family: string, variants: string[] = ['regular', '700']) => {
    // Skip system fonts
    if (SYSTEM_FONTS.find(f => f.family === family)) return

    const encodedFamily = family.replace(/ /g, '+')
    const weightsParam = variants
      .map(v => (v === 'regular' ? '400' : v === 'italic' ? '400i' : v.replace('italic', 'i')))
      .join(';')

    const href = `https://fonts.googleapis.com/css2?family=${encodedFamily}:wght@${weightsParam.replace(/i/g, '')}&display=swap`

    if (loadedLinksRef.current.has(href)) return
    loadedLinksRef.current.add(href)

    return new Promise<void>((resolve, reject) => {
      const link = document.createElement('link')
      link.rel = 'stylesheet'
      link.href = href
      link.crossOrigin = 'anonymous'
      link.onload = () => {
        loadedFonts.add(family)
        resolve()
      }
      link.onerror = reject
      document.head.appendChild(link)
    })
  }, [loadedFonts])

  // Search fonts by name
  const searchFonts = useCallback((query: string): GoogleFont[] => {
    if (!query.trim()) return fonts
    const q = query.toLowerCase()
    return fonts.filter(f => f.family.toLowerCase().includes(q))
  }, [fonts])

  // Get CSS properties for a font
  const getFontCSS = useCallback((
    family: string,
    size = 14,
    weight = '400'
  ): React.CSSProperties => ({
    fontFamily: `'${family}', monospace`,
    fontSize: `${size}px`,
    fontWeight: weight as any,
  }), [])

  return { fonts, loadedFonts, loading, error, loadFont, searchFonts, getFontCSS }
}

// ─── Preload common fonts ──────────────────────────────────────────────────

export function preloadCodingFonts(families: string[]) {
  families.forEach(family => {
    if (SYSTEM_FONTS.find(f => f.family === family)) return
    const encodedFamily = family.replace(/ /g, '+')
    const href = `https://fonts.googleapis.com/css2?family=${encodedFamily}:wght@300;400;500;600;700&display=swap`
    const existing = document.querySelector(`link[href="${href}"]`)
    if (!existing) {
      const link = document.createElement('link')
      link.rel = 'preconnect'
      link.href = 'https://fonts.googleapis.com'
      document.head.appendChild(link)

      const link2 = document.createElement('link')
      link2.rel = 'preconnect'
      link2.href = 'https://fonts.gstatic.com'
      link2.crossOrigin = 'anonymous'
      document.head.appendChild(link2)

      const styleLink = document.createElement('link')
      styleLink.rel = 'stylesheet'
      styleLink.href = href
      document.head.appendChild(styleLink)
    }
  })
}
