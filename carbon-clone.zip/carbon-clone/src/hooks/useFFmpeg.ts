import { useState, useRef, useCallback } from 'react'
import type { AnimationConfig } from '@/types'

interface UseFFmpegReturn {
  loaded: boolean
  loading: boolean
  progress: number
  error: string | null
  load: () => Promise<void>
  createTypingAnimation: (
    frames: string[],  // Array of base64 PNGs
    config: AnimationConfig,
    outputFormat: 'mp4' | 'gif' | 'webm'
  ) => Promise<Blob>
  createHighlightAnimation: (
    baseFrame: string,
    highlightFrames: string[],
    config: AnimationConfig
  ) => Promise<Blob>
  createFadeAnimation: (
    fromFrame: string,
    toFrame: string,
    config: AnimationConfig
  ) => Promise<Blob>
  cancel: () => void
}

export function useFFmpeg(): UseFFmpegReturn {
  const [loaded, setLoaded] = useState(false)
  const [loading, setLoading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const ffmpegRef = useRef<any>(null)
  const cancelledRef = useRef(false)

  const load = useCallback(async () => {
    if (loaded || loading) return
    setLoading(true)
    setError(null)

    try {
      const { FFmpeg } = await import('@ffmpeg/ffmpeg')
      const { toBlobURL } = await import('@ffmpeg/util')

      const ffmpeg = new FFmpeg()

      ffmpeg.on('progress', ({ progress: p }: { progress: number }) => {
        setProgress(Math.round(p * 100))
      })

      ffmpeg.on('log', ({ message }: { message: string }) => {
        console.debug('[ffmpeg]', message)
      })

      // Self-hosted to avoid CORS issues with COEP: require-corp
      const baseURL = "/ffmpeg"
      await ffmpeg.load({
        coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
        wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
      })

      ffmpegRef.current = ffmpeg
      setLoaded(true)
    } catch (err) {
      setError(`Failed to load FFmpeg: ${err}`)
    } finally {
      setLoading(false)
    }
  }, [loaded, loading])

  // Convert base64 PNG to Uint8Array
  const base64ToUint8Array = (base64: string): Uint8Array => {
    const binaryString = atob(base64.replace(/^data:image\/\w+;base64,/, ''))
    const bytes = new Uint8Array(binaryString.length)
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i)
    }
    return bytes
  }

  // Create typing animation: each frame shows more text
  const createTypingAnimation = useCallback(async (
    frames: string[],
    config: AnimationConfig,
    outputFormat: 'mp4' | 'gif' | 'webm' = 'mp4'
  ): Promise<Blob> => {
    if (!ffmpegRef.current) throw new Error('FFmpeg not loaded')
    const ffmpeg = ffmpegRef.current
    cancelledRef.current = false

    const { fetchFile } = await import('@ffmpeg/util')
    const fps = config.fps || 24
    const frameDuration = 1 / fps

    // Write all frames to virtual filesystem
    for (let i = 0; i < frames.length; i++) {
      if (cancelledRef.current) throw new Error('Cancelled')
      const frameData = base64ToUint8Array(frames[i])
      await ffmpeg.writeFile(`frame_${String(i).padStart(5, '0')}.png`, frameData)
    }

    const outputFile = `output.${outputFormat}`

    // Build FFmpeg command based on format
    const ffmpegArgs: string[] = [
      '-framerate', String(fps),
      '-i', 'frame_%05d.png',
    ]

    if (outputFormat === 'gif') {
      // High quality GIF with palette generation
      ffmpegArgs.push(
        '-filter_complex', '[0:v] palettegen=max_colors=256:stats_mode=full [pal]; [0:v][pal] paletteuse=dither=sierra2_4a',
        '-loop', '0',
        outputFile
      )
    } else if (outputFormat === 'webm') {
      ffmpegArgs.push(
        '-c:v', 'libvpx-vp9',
        '-pix_fmt', 'yuva420p',
        '-auto-alt-ref', '0',
        '-b:v', '0',
        '-crf', '18',
        outputFile
      )
    } else {
      // MP4
      ffmpegArgs.push(
        '-c:v', 'libx264',
        '-pix_fmt', 'yuv420p',
        '-crf', '18',
        '-preset', 'slow',
        '-movflags', '+faststart',
        outputFile
      )
    }

    await ffmpeg.exec(ffmpegArgs)

    const data = await ffmpeg.readFile(outputFile)

    // Cleanup
    for (let i = 0; i < frames.length; i++) {
      await ffmpeg.deleteFile(`frame_${String(i).padStart(5, '0')}.png`).catch(() => {})
    }
    await ffmpeg.deleteFile(outputFile).catch(() => {})

    const mimeTypes: Record<string, string> = {
      mp4: 'video/mp4',
      gif: 'image/gif',
      webm: 'video/webm',
    }

    return new Blob([data], { type: mimeTypes[outputFormat] || 'video/mp4' })
  }, [])

  // Create syntax highlight animation: scan through lines
  const createHighlightAnimation = useCallback(async (
    baseFrame: string,
    highlightFrames: string[],
    config: AnimationConfig
  ): Promise<Blob> => {
    if (!ffmpegRef.current) throw new Error('FFmpeg not loaded')
    const ffmpeg = ffmpegRef.current

    const fps = config.fps || 30
    const allFrames = [baseFrame, ...highlightFrames]

    for (let i = 0; i < allFrames.length; i++) {
      const frameData = base64ToUint8Array(allFrames[i])
      await ffmpeg.writeFile(`hframe_${String(i).padStart(5, '0')}.png`, frameData)
    }

    await ffmpeg.exec([
      '-framerate', String(fps),
      '-i', 'hframe_%05d.png',
      '-c:v', 'libx264',
      '-pix_fmt', 'yuv420p',
      '-crf', '20',
      'highlight_output.mp4',
    ])

    const data = await ffmpeg.readFile('highlight_output.mp4')

    // Cleanup
    for (let i = 0; i < allFrames.length; i++) {
      await ffmpeg.deleteFile(`hframe_${String(i).padStart(5, '0')}.png`).catch(() => {})
    }
    await ffmpeg.deleteFile('highlight_output.mp4').catch(() => {})

    return new Blob([data], { type: 'video/mp4' })
  }, [])

  // Create fade animation between two frames
  const createFadeAnimation = useCallback(async (
    fromFrame: string,
    toFrame: string,
    config: AnimationConfig
  ): Promise<Blob> => {
    if (!ffmpegRef.current) throw new Error('FFmpeg not loaded')
    const ffmpeg = ffmpegRef.current

    const fps = config.fps || 30
    const durationSec = (config.duration || 1000) / 1000
    const totalFrames = Math.round(fps * durationSec)

    // Generate intermediate frames with alpha blending
    const fromImg = await loadImageAsCanvas(fromFrame)
    const toImg = await loadImageAsCanvas(toFrame)
    const canvas = document.createElement('canvas')
    canvas.width = fromImg.width
    canvas.height = fromImg.height
    const ctx = canvas.getContext('2d')!

    for (let i = 0; i < totalFrames; i++) {
      const alpha = i / (totalFrames - 1)
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      ctx.globalAlpha = 1 - alpha
      ctx.drawImage(fromImg, 0, 0)
      ctx.globalAlpha = alpha
      ctx.drawImage(toImg, 0, 0)
      ctx.globalAlpha = 1

      const dataUrl = canvas.toDataURL('image/png')
      const frameData = base64ToUint8Array(dataUrl)
      await ffmpeg.writeFile(`fade_${String(i).padStart(5, '0')}.png`, frameData)
    }

    await ffmpeg.exec([
      '-framerate', String(fps),
      '-i', 'fade_%05d.png',
      '-c:v', 'libx264',
      '-pix_fmt', 'yuv420p',
      '-crf', '18',
      'fade_output.mp4',
    ])

    const data = await ffmpeg.readFile('fade_output.mp4')

    for (let i = 0; i < totalFrames; i++) {
      await ffmpeg.deleteFile(`fade_${String(i).padStart(5, '0')}.png`).catch(() => {})
    }
    await ffmpeg.deleteFile('fade_output.mp4').catch(() => {})

    return new Blob([data], { type: 'video/mp4' })
  }, [])

  const cancel = useCallback(() => {
    cancelledRef.current = true
    if (ffmpegRef.current) {
      try { ffmpegRef.current.terminate?.() } catch {}
    }
  }, [])

  return { loaded, loading, progress, error, load, createTypingAnimation, createHighlightAnimation, createFadeAnimation, cancel }
}

// ─── Helper ────────────────────────────────────────────────────────────────

function loadImageAsCanvas(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = reject
    img.src = src
  })
}

// ─── Frame Generator for Typing Animation ─────────────────────────────────

export async function generateTypingFrames(
  code: string,
  renderFrame: (partialCode: string) => Promise<string>
): Promise<string[]> {
  const frames: string[] = []

  // Generate frames at character intervals
  const totalChars = code.length
  const frameCount = Math.min(totalChars, 60) // Max 60 frames for typing

  const step = Math.max(1, Math.floor(totalChars / frameCount))

  for (let i = step; i <= totalChars; i += step) {
    const partialCode = code.slice(0, i)
    const frame = await renderFrame(partialCode)
    frames.push(frame)
  }

  // Ensure last frame is complete
  if (frames[frames.length - 1] !== code) {
    const lastFrame = await renderFrame(code)
    frames.push(lastFrame)
  }

  // Add hold frames at the end
  const holdFrames = 15
  const lastFrame = frames[frames.length - 1]
  for (let i = 0; i < holdFrames; i++) {
    frames.push(lastFrame)
  }

  return frames
}
