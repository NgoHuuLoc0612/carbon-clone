import React, { useState, useCallback, useRef } from 'react'
import { useEditorStore } from '@/store/editorStore'
import { useFFmpeg, generateTypingFrames } from '@/hooks/useFFmpeg'
import {
  exportAsPng, exportAsJpeg, exportAsSvg, exportAsWebp,
  exportViaPuppeteer, svgToPngViaResvg,
  extractElementForExport, downloadBlob, copyBlobToClipboard,
  getExportFilename,
} from '@/utils/export'
import type { ExportFormat, ExportQuality, AnimationType } from '@/types'
import clsx from 'clsx'
import * as htmlToImage from 'html-to-image'

interface ExportPanelProps {
  previewRef: React.RefObject<HTMLDivElement>
}

// ─── Format Config ────────────────────────────────────────────────────────

const FORMAT_INFO: Record<ExportFormat, { label: string; desc: string; icon: string; supportsAlpha?: boolean }> = {
  png:  { label: 'PNG',  desc: 'Lossless, supports transparency', icon: '🖼️', supportsAlpha: true },
  jpeg: { label: 'JPEG', desc: 'Smaller file, no transparency',   icon: '📸' },
  webp: { label: 'WebP', desc: 'Modern format, best compression',  icon: '✨', supportsAlpha: true },
  svg:  { label: 'SVG',  desc: 'Vector, infinitely scalable',      icon: '🔷', supportsAlpha: true },
  mp4:  { label: 'MP4',  desc: 'H.264 video, wide compatibility', icon: '🎬' },
  gif:  { label: 'GIF',  desc: 'Animated loop, wide support',     icon: '🎥' },
}

const METHOD_INFO = {
  'html-to-image': { label: 'html-to-image', desc: 'Fast, client-side rendering' },
  'puppeteer':     { label: 'Puppeteer',     desc: 'High-fidelity via headless Chrome' },
  'resvg':         { label: 'resvg-wasm',    desc: 'SVG → PNG, precise rendering' },
}

const SCALE_PRESETS = [1, 1.5, 2, 3, 4]
const VIDEO_FORMATS: ExportFormat[] = ['mp4', 'gif']
const STATIC_FORMATS: ExportFormat[] = ['png', 'svg', 'jpeg', 'webp']

const ANIMATION_TYPES: Array<{ id: AnimationType; label: string; desc: string }> = [
  { id: 'typing',         label: 'Typing',         desc: 'Code appears character by character' },
  { id: 'fade-in',        label: 'Fade In',         desc: 'Gentle opacity transition' },
  { id: 'slide-up',       label: 'Slide Up',        desc: 'Frame slides into view' },
  { id: 'highlight-scan', label: 'Highlight Scan', desc: 'Syntax highlighting applied line by line' },
  { id: 'none',           label: 'Static',          desc: 'Single frame, no animation' },
]

// ─── Export Panel ─────────────────────────────────────────────────────────

export function ExportPanel({ previewRef }: ExportPanelProps) {
  const store = useEditorStore()
  const { exportOptions } = store
  const ffmpeg = useFFmpeg()

  const [copied, setCopied] = useState(false)
  const [serverAvailable, setServerAvailable] = useState<boolean | null>(null)

  // Check server availability
  React.useEffect(() => {
    fetch('/api/health', { signal: AbortSignal.timeout(2000) })
      .then(() => setServerAvailable(true))
      .catch(() => setServerAvailable(false))
  }, [])

  const isVideo = VIDEO_FORMATS.includes(exportOptions.format)

  // ── Core export function ──

  const runExport = useCallback(async (action: 'download' | 'copy') => {
    const el = previewRef.current
    if (!el) return

    store.setExporting(true)
    store.setExportProgress(0)
    store.setExportError(null)

    try {
      let blob: Blob

      if (isVideo) {
        // Video/GIF export via ffmpeg.wasm
        if (!ffmpeg.loaded) {
          await ffmpeg.load()
        }

        store.setExportProgress(10)

        if (exportOptions.animation?.type === 'typing' || exportOptions.format === 'gif') {
          // Generate typing animation frames
          const frames = await generateTypingFrames(
            store.editor.code,
            async (partialCode) => {
              // Temporarily update code for rendering
              const originalCode = store.editor.code
              store.setCode(partialCode)
              await new Promise(r => setTimeout(r, 50))

              const dataUrl = await htmlToImage.toPng(el, {
                pixelRatio: exportOptions.scale || 2,
                cacheBust: true,
                skipFonts: true,
              })
              store.setCode(originalCode)
              return dataUrl
            }
          )

          store.setExportProgress(60)

          blob = await ffmpeg.createTypingAnimation(
            frames,
            exportOptions.animation || {
              type: 'typing',
              duration: 3000,
              fps: 30,
              delay: 0,
            },
            exportOptions.format as 'mp4' | 'gif'
          )
        } else {
          // Simple fade animation
          const fromDataUrl = await htmlToImage.toPng(el, { pixelRatio: exportOptions.scale || 2, cacheBust: true, skipFonts: true })
          blob = await ffmpeg.createFadeAnimation(
            fromDataUrl,
            fromDataUrl,
            exportOptions.animation || { type: 'fade-in', duration: 1000, fps: 30, delay: 0 }
          )
        }

        store.setExportProgress(90)
      } else {
        // Static image export
        const method = exportOptions.method

        if (method === 'puppeteer' && serverAvailable) {
          const { html, css } = extractElementForExport(el)
          const rect = el.getBoundingClientRect()
          blob = await exportViaPuppeteer({
            html,
            css,
            width: Math.ceil(rect.width),
            height: Math.ceil(rect.height),
            scale: exportOptions.scale,
            format: exportOptions.format as 'png' | 'jpeg' | 'webp',
          })
        } else if (method === 'resvg' && exportOptions.format === 'png') {
          const svgBlob = await exportAsSvg(el)
          const svgText = await svgBlob.text()
          blob = await svgToPngViaResvg(svgText, {
            scale: exportOptions.scale,
            defaultFontFamily: store.editor.fontFamily,
          })
        } else {
          switch (exportOptions.format) {
            case 'jpeg': blob = await exportAsJpeg(el, exportOptions); break
            case 'webp': blob = await exportAsWebp(el, exportOptions); break
            case 'svg':  blob = await exportAsSvg(el);                  break
            default:     blob = await exportAsPng(el, exportOptions);   break
          }
        }

        store.setExportProgress(90)
      }

      store.setExportProgress(95)

      if (action === 'download') {
        const filename = getExportFilename(exportOptions.format, store.window.title || 'carbon')
        downloadBlob(blob, filename)
      } else {
        try {
          await copyBlobToClipboard(blob)
          setCopied(true)
          setTimeout(() => setCopied(false), 2000)
        } catch {
          // Fallback: download if clipboard not available
          const filename = getExportFilename(exportOptions.format, store.window.title || 'carbon')
          downloadBlob(blob, filename)
        }
      }

      store.setExportProgress(100)
    } catch (err) {
      store.setExportError(String(err))
      console.error('Export error:', err)
    } finally {
      setTimeout(() => {
        store.setExporting(false)
        store.setExportProgress(0)
      }, 500)
    }
  }, [previewRef, store, exportOptions, isVideo, ffmpeg, serverAvailable])

  return (
    <div className="flex flex-col h-full bg-[#12141a] overflow-y-auto" style={{ scrollbarWidth: 'thin' }}>
      <div className="p-4 border-b border-white/[0.06]">
        <h2 className="text-xs font-bold uppercase tracking-[0.15em] text-white/30">Export</h2>
      </div>

      <div className="p-4 space-y-5 flex-1">
        {/* Format */}
        <div>
          <label className="block text-[11px] font-semibold uppercase tracking-widest text-white/30 mb-2">
            Format
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {(Object.entries(FORMAT_INFO) as Array<[ExportFormat, typeof FORMAT_INFO[ExportFormat]]>).map(([fmt, info]) => (
              <button
                key={fmt}
                onClick={() => store.setExportOptions({ format: fmt })}
                className={clsx(
                  'flex flex-col items-center gap-1 py-2.5 px-1 rounded-xl text-xs font-medium transition-all border',
                  exportOptions.format === fmt
                    ? 'bg-indigo-600/20 border-indigo-500/50 text-indigo-300'
                    : 'bg-white/[0.03] border-white/[0.06] text-white/40 hover:text-white/70 hover:bg-white/[0.06]'
                )}
              >
                <span className="text-base">{info.icon}</span>
                <span>{info.label}</span>
              </button>
            ))}
          </div>
          <p className="mt-2 text-[11px] text-white/30 italic">
            {FORMAT_INFO[exportOptions.format]?.desc}
          </p>
        </div>

        {/* Scale / Quality (static only) */}
        {!isVideo && (
          <>
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-widest text-white/30 mb-2">
                Scale
              </label>
              <div className="flex gap-1.5">
                {SCALE_PRESETS.map(s => (
                  <button
                    key={s}
                    onClick={() => store.setExportOptions({ scale: s })}
                    className={clsx(
                      'flex-1 py-1.5 rounded-lg text-xs font-mono font-medium transition-all',
                      exportOptions.scale === s
                        ? 'bg-indigo-600 text-white'
                        : 'bg-white/5 text-white/40 hover:text-white/70'
                    )}
                  >
                    {s}×
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-widest text-white/30 mb-2">
                Method
              </label>
              <div className="space-y-1.5">
                {(Object.entries(METHOD_INFO) as Array<[typeof exportOptions.method, typeof METHOD_INFO[keyof typeof METHOD_INFO]]>).map(([m, info]) => (
                  <button
                    key={m}
                    onClick={() => store.setExportOptions({ method: m })}
                    disabled={m === 'puppeteer' && !serverAvailable}
                    className={clsx(
                      'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all text-left',
                      exportOptions.method === m
                        ? 'bg-indigo-600/20 ring-1 ring-indigo-500/40 text-indigo-300'
                        : 'bg-white/[0.03] text-white/50 hover:bg-white/[0.06] hover:text-white/70',
                      m === 'puppeteer' && !serverAvailable && 'opacity-40 cursor-not-allowed'
                    )}
                  >
                    <span className="flex-1 min-w-0">
                      <span className="block font-medium text-xs">{info.label}</span>
                      <span className="block text-[11px] opacity-60">{info.desc}</span>
                    </span>
                    {m === 'puppeteer' && (
                      <span className={clsx(
                        'text-[10px] px-1.5 py-0.5 rounded-full flex-shrink-0',
                        serverAvailable ? 'bg-green-900/40 text-green-400' : 'bg-red-900/40 text-red-400'
                      )}>
                        {serverAvailable ? 'online' : 'offline'}
                      </span>
                    )}
                    {exportOptions.method === m && (
                      <span className="text-indigo-400 text-xs flex-shrink-0">✓</span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Animation config (video only) */}
        {isVideo && (
          <div className="space-y-4">
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-widest text-white/30 mb-2">
                Animation
              </label>
              {!ffmpeg.loaded && (
                <div className="mb-3 flex items-center gap-2 p-2.5 rounded-lg bg-amber-900/20 border border-amber-500/20">
                  <span className="text-amber-400 text-xs">⚠️ FFmpeg WASM required</span>
                  {!ffmpeg.loading ? (
                    <button
                      onClick={() => ffmpeg.load()}
                      className="ml-auto text-xs bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 px-2 py-0.5 rounded transition-colors"
                    >
                      Load
                    </button>
                  ) : (
                    <span className="ml-auto text-xs text-amber-300">
                      Loading… {ffmpeg.progress}%
                    </span>
                  )}
                </div>
              )}

              <div className="space-y-1.5">
                {ANIMATION_TYPES.map(anim => (
                  <button
                    key={anim.id}
                    onClick={() => store.setExportOptions({
                      animation: {
                        type: anim.id,
                        duration: exportOptions.animation?.duration || 3000,
                        fps: exportOptions.animation?.fps || 30,
                        delay: exportOptions.animation?.delay || 0,
                      }
                    })}
                    className={clsx(
                      'w-full flex flex-col px-3 py-2 rounded-lg text-sm transition-all text-left',
                      exportOptions.animation?.type === anim.id
                        ? 'bg-indigo-600/20 ring-1 ring-indigo-500/40 text-indigo-300'
                        : 'bg-white/[0.03] text-white/50 hover:bg-white/[0.06] hover:text-white/70'
                    )}
                  >
                    <span className="font-medium text-xs">{anim.label}</span>
                    <span className="text-[11px] opacity-60">{anim.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-widest text-white/30 mb-2">
                Duration (ms)
              </label>
              <input
                type="range" min={500} max={10000} step={100}
                value={exportOptions.animation?.duration || 3000}
                onChange={e => store.setExportOptions({
                  animation: {
                    ...exportOptions.animation!,
                    type: exportOptions.animation?.type || 'typing',
                    duration: Number(e.target.value),
                    fps: exportOptions.animation?.fps || 30,
                    delay: exportOptions.animation?.delay || 0,
                  }
                })}
                className="w-full h-1 accent-indigo-500"
              />
              <div className="flex justify-between text-[11px] text-white/30 mt-1">
                <span>0.5s</span>
                <span className="text-white/50 font-mono">
                  {((exportOptions.animation?.duration || 3000) / 1000).toFixed(1)}s
                </span>
                <span>10s</span>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-widest text-white/30 mb-2">
                FPS
              </label>
              <div className="flex gap-1.5">
                {[15, 24, 30, 60].map(fps => (
                  <button
                    key={fps}
                    onClick={() => store.setExportOptions({
                      animation: {
                        ...exportOptions.animation!,
                        type: exportOptions.animation?.type || 'typing',
                        fps,
                        duration: exportOptions.animation?.duration || 3000,
                        delay: exportOptions.animation?.delay || 0,
                      }
                    })}
                    className={clsx(
                      'flex-1 py-1.5 rounded-lg text-xs font-mono font-medium transition-all',
                      exportOptions.animation?.fps === fps
                        ? 'bg-indigo-600 text-white'
                        : 'bg-white/5 text-white/40 hover:text-white/70'
                    )}
                  >
                    {fps}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Error display */}
        {store.exportError && (
          <div className="p-3 rounded-lg bg-red-900/20 border border-red-500/30 text-red-400 text-xs">
            {store.exportError}
          </div>
        )}
      </div>

      {/* Progress bar */}
      {store.isExporting && store.exportProgress > 0 && (
        <div className="px-4 pb-2">
          <div className="h-1 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-indigo-500 rounded-full transition-all duration-300"
              style={{ width: `${store.exportProgress}%` }}
            />
          </div>
          <p className="text-[11px] text-white/30 mt-1 text-center">{store.exportProgress}%</p>
        </div>
      )}

      {/* Action buttons */}
      <div className="p-4 border-t border-white/[0.06] space-y-2">
        <button
          onClick={() => runExport('download')}
          disabled={store.isExporting}
          className={clsx(
            'w-full py-3 rounded-xl text-sm font-semibold transition-all relative overflow-hidden',
            store.isExporting
              ? 'bg-indigo-600/50 text-white/50 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20 hover:shadow-indigo-500/30 active:scale-[0.98]'
          )}
        >
          {store.isExporting ? (
            <span className="flex items-center justify-center gap-2">
              <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeDasharray="32" strokeDashoffset="32" />
              </svg>
              Exporting…
            </span>
          ) : (
            `↓ Download ${FORMAT_INFO[exportOptions.format]?.label}`
          )}
        </button>

        {!isVideo && (
          <button
            onClick={() => runExport('copy')}
            disabled={store.isExporting}
            className={clsx(
              'w-full py-2.5 rounded-xl text-sm font-medium transition-all',
              copied
                ? 'bg-green-600/20 text-green-400 border border-green-500/30'
                : 'bg-white/[0.05] hover:bg-white/[0.08] text-white/60 hover:text-white/80 border border-white/[0.06]'
            )}
          >
            {copied ? '✓ Copied!' : '⎘ Copy to Clipboard'}
          </button>
        )}

        <button
          onClick={store.resetToDefault}
          className="w-full py-2 rounded-xl text-xs text-white/25 hover:text-white/40 transition-colors"
        >
          Reset All Settings
        </button>
      </div>
    </div>
  )
}
