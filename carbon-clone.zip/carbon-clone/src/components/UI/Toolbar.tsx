import React, { useState, useCallback } from 'react'
import { useEditorStore } from '@/store/editorStore'
import { LanguageSelector } from '@/components/UI/LanguageSelector'
import { SHIKI_THEMES } from '@/hooks/useShiki'
import { copyShareableUrl } from '@/utils/urlState'
import clsx from 'clsx'

interface ToolbarProps {
  onExport: () => void
  onDiff: () => void
  activePanel: 'controls' | 'presets' | 'export'
  onPanelChange: (p: 'controls' | 'presets' | 'export') => void
}

export function Toolbar({ onExport, onDiff, activePanel, onPanelChange }: ToolbarProps) {
  const store = useEditorStore()
  const { editor } = store
  const [copied, setCopied] = useState(false)

  const currentTheme = SHIKI_THEMES.find(t => t.id === editor.theme)

  const handleShare = useCallback(async () => {
    try {
      await copyShareableUrl(store as any)
      setCopied(true)
      setTimeout(() => setCopied(false), 2500)
    } catch (err) {
      console.error('Share failed:', err)
    }
  }, [store])

  return (
    <header className="flex items-center gap-3 px-4 py-2.5 bg-[#0d0f14] border-b border-white/[0.06] flex-shrink-0">
      {/* Logo */}
      <div className="flex items-center gap-2 mr-2 flex-shrink-0">
        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
          <span className="text-white text-xs font-bold font-mono">C</span>
        </div>
        <span className="text-white font-semibold text-sm tracking-tight hidden sm:block">
          carbon<span className="text-indigo-400">.</span>
        </span>
      </div>

      {/* Panel tabs */}
      <div className="flex items-center gap-1 bg-white/[0.04] p-1 rounded-xl mr-2">
        {([
          { id: 'controls', label: '⚙ Controls' },
          { id: 'presets',  label: '✦ Presets' },
          { id: 'export',   label: '↓ Export' },
        ] as const).map(tab => (
          <button
            key={tab.id}
            onClick={() => onPanelChange(tab.id)}
            className={clsx(
              'px-3 py-1 rounded-lg text-xs font-medium transition-all whitespace-nowrap',
              activePanel === tab.id
                ? 'bg-white/10 text-white shadow-sm'
                : 'text-white/40 hover:text-white/60'
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Language selector */}
      <LanguageSelector />

      {/* Theme quick-switch indicator */}
      <div className="flex items-center gap-1.5 ml-1">
        <span
          className="w-4 h-4 rounded border border-white/10 flex-shrink-0"
          style={{ background: currentTheme?.preview }}
        />
        <span className="text-xs text-white/40 hidden md:block max-w-[120px] truncate">
          {currentTheme?.name}
        </span>
      </div>

      <div className="flex-1" />

      {/* Diff button */}
      <button
        onClick={onDiff}
        title="Open diff viewer"
        className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white/40 hover:text-white/70 bg-white/[0.04] hover:bg-white/[0.07] transition-all border border-white/[0.06]"
      >
        ⟷ Diff
      </button>

      {/* Share button */}
      <button
        onClick={handleShare}
        title="Copy shareable URL to clipboard"
        className={clsx(
          'hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all border',
          copied
            ? 'bg-green-600/20 border-green-500/30 text-green-400'
            : 'text-white/40 hover:text-white/70 bg-white/[0.04] hover:bg-white/[0.07] border-white/[0.06]'
        )}
      >
        {copied ? '✓ URL Copied' : '⎋ Share URL'}
      </button>

      {/* Keyboard hint */}
      <kbd className="hidden xl:flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/[0.04] border border-white/[0.08] text-[10px] text-white/25 font-mono">
        ⌘E export
      </kbd>

      {/* Export button */}
      <button
        onClick={onExport}
        className="flex items-center gap-2 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg transition-all shadow-lg shadow-indigo-500/20 active:scale-[0.97]"
      >
        ↓ Export
      </button>
    </header>
  )
}
