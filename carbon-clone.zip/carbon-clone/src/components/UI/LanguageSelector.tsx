import React, { useState, useRef, useEffect } from 'react'
import { useEditorStore } from '@/store/editorStore'
import { SHIKI_LANGUAGES } from '@/hooks/useShiki'
import clsx from 'clsx'

export function LanguageSelector() {
  const store = useEditorStore()
  const { editor } = store
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const ref = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const filtered = SHIKI_LANGUAGES.filter(l =>
    l.name.toLowerCase().includes(search.toLowerCase()) ||
    l.id.toLowerCase().includes(search.toLowerCase()) ||
    (l.aliases || []).some(a => a.toLowerCase().includes(search.toLowerCase()))
  )

  const currentLang = SHIKI_LANGUAGES.find(l => l.id === editor.language)

  useEffect(() => {
    if (open) {
      inputRef.current?.focus()
    }
  }, [open])

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className={clsx(
          'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all',
          'bg-white/[0.06] hover:bg-white/10 text-white/70 hover:text-white border border-white/[0.08]'
        )}
      >
        <span className="text-xs text-indigo-400 font-mono">{currentLang?.id || editor.language}</span>
        <span className="text-white/40">▾</span>
      </button>

      {open && (
        <div className="absolute top-full mt-1 left-0 z-50 w-56 bg-[#1a1d24] border border-white/10 rounded-xl shadow-2xl shadow-black/60 overflow-hidden">
          <div className="p-2 border-b border-white/5">
            <input
              ref={inputRef}
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Filter languages…"
              className="w-full bg-white/5 rounded-lg px-3 py-1.5 text-sm text-white placeholder-white/25 focus:outline-none focus:bg-white/8"
            />
          </div>
          <div className="max-h-64 overflow-y-auto py-1" style={{ scrollbarWidth: 'thin' }}>
            {filtered.length === 0 ? (
              <p className="text-center text-white/25 text-sm py-4">No languages found</p>
            ) : (
              filtered.map(lang => (
                <button
                  key={lang.id}
                  onClick={() => {
                    store.setLanguage(lang.id)
                    setOpen(false)
                    setSearch('')
                  }}
                  className={clsx(
                    'w-full flex items-center gap-3 px-3 py-2 text-sm transition-colors text-left',
                    editor.language === lang.id
                      ? 'bg-indigo-600/20 text-indigo-300'
                      : 'text-white/60 hover:bg-white/5 hover:text-white'
                  )}
                >
                  <span className="font-medium text-xs min-w-0 flex-1">{lang.name}</span>
                  <span className="text-[10px] text-white/25 font-mono flex-shrink-0">{lang.id}</span>
                  {editor.language === lang.id && (
                    <span className="text-indigo-400 text-xs flex-shrink-0">✓</span>
                  )}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  )
}
