import React, { useCallback, useEffect, useRef, useState } from 'react'
import MonacoEditor, { useMonaco, OnMount, OnChange } from '@monaco-editor/react'
import type { editor } from 'monaco-editor'
import { useEditorStore } from '@/store/editorStore'
import { useTreeSitter } from '@/hooks/useTreeSitter'
import type { EditorConfig } from '@/types'
import clsx from 'clsx'

// ─── Monaco Language to Shiki Language Map ────────────────────────────────

const MONACO_LANG_MAP: Record<string, string> = {
  typescript: 'typescript',
  javascript: 'javascript',
  tsx: 'typescript',
  jsx: 'javascript',
  python: 'python',
  rust: 'rust',
  go: 'go',
  java: 'java',
  kotlin: 'kotlin',
  swift: 'swift',
  c: 'c',
  cpp: 'cpp',
  csharp: 'csharp',
  ruby: 'ruby',
  php: 'php',
  html: 'html',
  css: 'css',
  scss: 'scss',
  json: 'json',
  yaml: 'yaml',
  bash: 'shell',
  sql: 'sql',
  markdown: 'markdown',
  graphql: 'graphql',
  shell: 'shell',
}

// ─── Editor Options ────────────────────────────────────────────────────────

function buildEditorOptions(config: EditorConfig): editor.IStandaloneEditorConstructionOptions {
  return {
    minimap: { enabled: false },
    scrollBeyondLastLine: false,
    lineNumbers: config.showLineNumbers ? 'on' : 'off',
    lineNumbersMinChars: 3,
    renderLineHighlight: 'line',
    fontSize: config.fontSize,
    fontFamily: `'${config.fontFamily}', 'JetBrains Mono', 'Fira Code', monospace`,
    fontLigatures: true,
    lineHeight: config.fontSize * config.lineHeight,
    tabSize: config.tabSize,
    insertSpaces: true,
    wordWrap: config.wrapLines ? 'on' : 'off',
    automaticLayout: true,
    scrollbar: {
      vertical: 'hidden',
      horizontal: 'hidden',
      handleMouseWheel: false,
    },
    overviewRulerLanes: 0,
    hideCursorInOverviewRuler: true,
    renderWhitespace: config.showWhiteSpace ? 'all' : 'none',
    padding: { top: 20, bottom: 20 },
    cursorBlinking: 'smooth',
    cursorSmoothCaretAnimation: 'on',
    smoothScrolling: true,
    contextmenu: true,
    folding: true,
    foldingStrategy: 'indentation',
    showFoldingControls: 'mouseover',
    bracketPairColorization: { enabled: true },
    guides: {
      bracketPairs: true,
      indentation: true,
    },
    lightbulb: { enabled: 'on' } as any,
    suggest: {
      showKeywords: true,
      showSnippets: true,
    },
    quickSuggestions: {
      other: 'on',
      comments: 'off',
      strings: 'off',
    },
  }
}

// ─── Component ────────────────────────────────────────────────────────────

interface CodeEditorProps {
  className?: string
  onAnalysisUpdate?: (analysis: any) => void
}

export function CodeEditor({ className, onAnalysisUpdate }: CodeEditorProps) {
  const store = useEditorStore()
  const { editor: config } = store
  const monaco = useMonaco()
  const editorRef = useRef<editor.IStandaloneCodeEditor | null>(null)
  const { parseCode, analysis, ready: tsReady } = useTreeSitter()
  const parseDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [editorTheme, setEditorTheme] = useState<string>('vs-dark')

  // Map shiki theme → Monaco theme
  const MONACO_THEME_MAP: Record<string, string> = {
    'github-dark': 'github-dark',
    'github-light': 'github-light',
    'github-dark-dimmed': 'github-dark',
    'one-dark-pro': 'one-dark-pro',
    'dracula': 'dracula',
    'nord': 'vs-dark',
    default: 'vs-dark',
  }

  // Set up custom Monaco themes
  useEffect(() => {
    if (!monaco) return

    // GitHub Dark
    monaco.editor.defineTheme('github-dark', {
      base: 'vs-dark',
      inherit: true,
      rules: [
        { token: 'keyword', foreground: 'ff7b72' },
        { token: 'string', foreground: 'a5d6ff' },
        { token: 'comment', foreground: '8b949e', fontStyle: 'italic' },
        { token: 'number', foreground: '79c0ff' },
        { token: 'type', foreground: 'ffa657' },
        { token: 'variable', foreground: 'e6edf3' },
        { token: 'function', foreground: 'd2a8ff' },
        { token: 'identifier', foreground: 'e6edf3' },
      ],
      colors: {
        'editor.background': '#0d1117',
        'editor.foreground': '#e6edf3',
        'editor.lineHighlightBackground': '#161b22',
        'editor.selectionBackground': '#264f78',
        'editorCursor.foreground': '#58a6ff',
        'editorLineNumber.foreground': '#6e7681',
        'editorLineNumber.activeForeground': '#e6edf3',
        'editor.findMatchBackground': '#9e6a0340',
        'editor.findMatchHighlightBackground': '#9e6a0320',
      },
    })

    // One Dark Pro
    monaco.editor.defineTheme('one-dark-pro', {
      base: 'vs-dark',
      inherit: true,
      rules: [
        { token: 'keyword', foreground: 'c678dd' },
        { token: 'string', foreground: '98c379' },
        { token: 'comment', foreground: '5c6370', fontStyle: 'italic' },
        { token: 'number', foreground: 'd19a66' },
        { token: 'type', foreground: 'e5c07b' },
        { token: 'function', foreground: '61afef' },
        { token: 'variable', foreground: 'e06c75' },
      ],
      colors: {
        'editor.background': '#282c34',
        'editor.foreground': '#abb2bf',
        'editor.lineHighlightBackground': '#2c323c',
        'editorCursor.foreground': '#528bff',
        'editorLineNumber.foreground': '#4b5263',
      },
    })

    // Dracula
    monaco.editor.defineTheme('dracula', {
      base: 'vs-dark',
      inherit: true,
      rules: [
        { token: 'keyword', foreground: 'ff79c6' },
        { token: 'string', foreground: 'f1fa8c' },
        { token: 'comment', foreground: '6272a4', fontStyle: 'italic' },
        { token: 'number', foreground: 'bd93f9' },
        { token: 'type', foreground: '8be9fd' },
        { token: 'function', foreground: '50fa7b' },
        { token: 'variable', foreground: 'f8f8f2' },
      ],
      colors: {
        'editor.background': '#282a36',
        'editor.foreground': '#f8f8f2',
        'editor.lineHighlightBackground': '#44475a',
        'editorCursor.foreground': '#f8f8f0',
        'editorLineNumber.foreground': '#6272a4',
      },
    })

    // GitHub Light
    monaco.editor.defineTheme('github-light', {
      base: 'vs',
      inherit: true,
      rules: [
        { token: 'keyword', foreground: 'cf222e' },
        { token: 'string', foreground: '0a3069' },
        { token: 'comment', foreground: '6e7781', fontStyle: 'italic' },
        { token: 'function', foreground: '8250df' },
      ],
      colors: {
        'editor.background': '#ffffff',
        'editor.foreground': '#24292f',
        'editorLineNumber.foreground': '#6e7781',
      },
    })

    const mappedTheme = MONACO_THEME_MAP[config.theme] || 'vs-dark'
    setEditorTheme(mappedTheme)
    monaco.editor.setTheme(mappedTheme)
  }, [monaco, config.theme])

  const handleMount: OnMount = useCallback((ed) => {
    editorRef.current = ed

    // Initial parse
    if (tsReady) {
      parseCode(config.code, config.language)
    }

    // Add action: copy as image (triggers export)
    ed.addAction({
      id: 'carbon.copy-as-image',
      label: 'Carbon: Copy as Image',
      keybindings: [
        monaco?.KeyMod.CtrlCmd! | monaco?.KeyCode.KeyE!,
      ],
      run: () => {
        document.dispatchEvent(new CustomEvent('carbon:export', { detail: { format: 'png' } }))
      },
    })

    // Resize observer
    const resizeObserver = new ResizeObserver(() => ed.layout())
    resizeObserver.observe(ed.getContainerDomNode()!)
    return () => resizeObserver.disconnect()
  }, [tsReady, config.code, config.language, monaco])

  const handleChange: OnChange = useCallback((value = '') => {
    store.setCode(value)

    // Debounce tree-sitter parsing
    if (parseDebounceRef.current) clearTimeout(parseDebounceRef.current)
    parseDebounceRef.current = setTimeout(() => {
      if (tsReady) {
        parseCode(value, config.language)
      }
    }, 400)
  }, [store, tsReady, parseCode, config.language])

  // Update analysis in parent
  useEffect(() => {
    if (analysis && onAnalysisUpdate) {
      onAnalysisUpdate(analysis)
    }
  }, [analysis, onAnalysisUpdate])

  // Mark tree-sitter errors in Monaco
  useEffect(() => {
    if (!monaco || !editorRef.current || !analysis) return

    const model = editorRef.current.getModel()
    if (!model) return

    const markers = analysis.errors.map(err => ({
      severity: monaco.MarkerSeverity.Error,
      startLineNumber: err.startRow + 1,
      startColumn: err.startCol + 1,
      endLineNumber: err.endRow + 1,
      endColumn: err.endCol + 1,
      message: err.message,
      source: 'Tree-sitter',
    }))

    monaco.editor.setModelMarkers(model, 'tree-sitter', markers)
  }, [monaco, analysis])

  const monacoLanguage = MONACO_LANG_MAP[config.language] || config.language

  return (
    <div className={clsx('relative flex flex-col h-full', className)}>
      {/* Status bar */}
      <div className="flex items-center justify-between px-4 py-1.5 bg-[#161b22] border-b border-white/[0.06] text-xs text-[#6e7681] font-mono">
        <div className="flex items-center gap-4">
          <span className="capitalize">{config.language}</span>
          {analysis && (
            <>
              <span>{analysis.lineCount} lines</span>
              <span>{analysis.charCount} chars</span>
              {analysis.complexity > 0 && (
                <span className={clsx(
                  'px-1.5 py-0.5 rounded text-[10px]',
                  analysis.complexity <= 5 ? 'bg-green-900/40 text-green-400' :
                  analysis.complexity <= 10 ? 'bg-yellow-900/40 text-yellow-400' :
                  'bg-red-900/40 text-red-400'
                )}>
                  CC: {analysis.complexity}
                </span>
              )}
            </>
          )}
        </div>
        <div className="flex items-center gap-4">
          {tsReady && (
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
              Tree-sitter
            </span>
          )}
          {analysis?.errors.length ? (
            <span className="text-red-400">{analysis.errors.length} error{analysis.errors.length !== 1 ? 's' : ''}</span>
          ) : null}
          <span>Tab: {config.tabSize}</span>
          <span>UTF-8</span>
        </div>
      </div>

      <div className="flex-1 min-h-0">
        <MonacoEditor
          language={monacoLanguage}
          value={config.code}
          theme={editorTheme}
          options={buildEditorOptions(config)}
          onChange={handleChange}
          onMount={handleMount}
          loading={
            <div className="flex items-center justify-center h-full bg-[#0d1117] text-[#6e7681] text-sm">
              Loading editor…
            </div>
          }
        />
      </div>
    </div>
  )
}
