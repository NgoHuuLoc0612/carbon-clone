import React, { useState, useEffect, useRef } from 'react'
import { useEditorStore } from '@/store/editorStore'
import { useShiki } from '@/hooks/useShiki'
import clsx from 'clsx'

interface DiffLine {
  type: 'context' | 'added' | 'removed'
  content: string
  lineNumberOld: number | null
  lineNumberNew: number | null
}

// ─── Myers Diff Algorithm ─────────────────────────────────────────────────

function computeDiff(oldLines: string[], newLines: string[]): DiffLine[] {
  const N = oldLines.length
  const M = newLines.length
  const max = N + M
  const v: Map<number, number> = new Map()
  v.set(1, 0)
  const trace: Map<number, number>[] = []

  outer:
  for (let d = 0; d <= max; d++) {
    trace.push(new Map(v))
    for (let k = -d; k <= d; k += 2) {
      let x: number
      const vKm1 = v.get(k - 1) ?? -1
      const vKp1 = v.get(k + 1) ?? -1
      if (k === -d || (k !== d && vKm1 < vKp1)) {
        x = vKp1
      } else {
        x = vKm1 + 1
      }
      let y = x - k
      while (x < N && y < M && oldLines[x] === newLines[y]) {
        x++; y++
      }
      v.set(k, x)
      if (x >= N && y >= M) break outer
    }
  }

  // Backtrack
  const path: Array<[number, number, number, number]> = []
  let x = N, y = M
  for (let d = trace.length - 1; d >= 0 && (x > 0 || y > 0); d--) {
    const vd = trace[d]
    const k = x - y
    let prevK: number
    const vKm1 = vd.get(k - 1) ?? -1
    const vKp1 = vd.get(k + 1) ?? -1
    if (k === -d || (k !== d && vKm1 < vKp1)) {
      prevK = k + 1
    } else {
      prevK = k - 1
    }
    const prevX = vd.get(prevK) ?? 0
    const prevY = prevX - prevK
    while (x > prevX + 1 && y > prevY + 1) {
      path.push([x - 1, y - 1, x, y])
      x--; y--
    }
    if (d > 0) {
      path.push([prevX, prevY, x, y])
    }
    x = prevX; y = prevY
  }
  path.reverse()

  // Convert path to diff lines
  const result: DiffLine[] = []
  let ox = 0, ny = 0
  for (const [px, py, cx, cy] of path) {
    // Snake (context)
    while (ox < px && ny < py) {
      result.push({ type: 'context', content: oldLines[ox], lineNumberOld: ox + 1, lineNumberNew: ny + 1 })
      ox++; ny++
    }
    if (cx === ox + 1 && cy === ny) {
      result.push({ type: 'removed', content: oldLines[ox], lineNumberOld: ox + 1, lineNumberNew: null })
      ox++
    } else if (cx === ox && cy === ny + 1) {
      result.push({ type: 'added', content: newLines[ny], lineNumberOld: null, lineNumberNew: ny + 1 })
      ny++
    } else if (cx > ox) {
      result.push({ type: 'context', content: oldLines[ox], lineNumberOld: ox + 1, lineNumberNew: ny + 1 })
      ox++; ny++
    }
  }
  while (ox < oldLines.length) {
    result.push({ type: 'removed', content: oldLines[ox], lineNumberOld: ox + 1, lineNumberNew: null })
    ox++
  }
  while (ny < newLines.length) {
    result.push({ type: 'added', content: newLines[ny], lineNumberOld: null, lineNumberNew: ny + 1 })
    ny++
  }
  return result
}

// ─── Diff Component ───────────────────────────────────────────────────────

interface DiffViewerProps {
  oldCode: string
  newCode: string
  onClose: () => void
}

export function DiffViewer({ oldCode, newCode, onClose }: DiffViewerProps) {
  const { editor } = useEditorStore()
  const { highlighted: hiOld } = useShiki({ code: oldCode, language: editor.language, theme: editor.theme })
  const { highlighted: hiNew } = useShiki({ code: newCode, language: editor.language, theme: editor.theme })

  const diff = React.useMemo(() => {
    return computeDiff(oldCode.split('\n'), newCode.split('\n'))
  }, [oldCode, newCode])

  const addedCount = diff.filter(d => d.type === 'added').length
  const removedCount = diff.filter(d => d.type === 'removed').length

  return (
    <div className="flex flex-col h-full bg-[#0d1117] rounded-xl overflow-hidden border border-white/[0.06]">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/[0.06] bg-[#12141a]">
        <div className="flex items-center gap-4">
          <span className="text-sm font-semibold text-white/80">Diff View</span>
          <span className="text-xs font-mono text-green-400">+{addedCount}</span>
          <span className="text-xs font-mono text-red-400">-{removedCount}</span>
        </div>
        <button
          onClick={onClose}
          className="text-white/30 hover:text-white/70 transition-colors text-lg leading-none"
        >
          ×
        </button>
      </div>

      {/* Side-by-side diff */}
      <div className="flex flex-1 min-h-0 overflow-auto font-mono text-sm"
        style={{ fontFamily: `'${editor.fontFamily}', monospace`, fontSize: editor.fontSize }}>
        {/* Old */}
        <div className="flex-1 min-w-0 border-r border-white/[0.06] overflow-x-auto">
          <div className="px-1 py-2 bg-red-900/10 border-b border-red-500/10">
            <span className="text-xs text-red-400 font-sans px-3">Before</span>
          </div>
          {diff.map((line, i) => (
            (line.type === 'context' || line.type === 'removed') && (
              <div
                key={`old-${i}`}
                className={clsx(
                  'flex items-start leading-relaxed',
                  line.type === 'removed' ? 'bg-red-900/20' : ''
                )}
              >
                <span className="w-10 flex-shrink-0 text-right pr-3 text-white/20 select-none text-xs py-0.5">
                  {line.lineNumberOld}
                </span>
                <span className={clsx(
                  'flex-1 px-2 py-0.5 whitespace-pre',
                  line.type === 'removed' ? 'text-red-300' : 'text-white/70'
                )}>
                  {line.type === 'removed' && <span className="text-red-400 mr-1">-</span>}
                  {line.content || ' '}
                </span>
              </div>
            )
          ))}
        </div>

        {/* New */}
        <div className="flex-1 min-w-0 overflow-x-auto">
          <div className="px-1 py-2 bg-green-900/10 border-b border-green-500/10">
            <span className="text-xs text-green-400 font-sans px-3">After</span>
          </div>
          {diff.map((line, i) => (
            (line.type === 'context' || line.type === 'added') && (
              <div
                key={`new-${i}`}
                className={clsx(
                  'flex items-start leading-relaxed',
                  line.type === 'added' ? 'bg-green-900/20' : ''
                )}
              >
                <span className="w-10 flex-shrink-0 text-right pr-3 text-white/20 select-none text-xs py-0.5">
                  {line.lineNumberNew}
                </span>
                <span className={clsx(
                  'flex-1 px-2 py-0.5 whitespace-pre',
                  line.type === 'added' ? 'text-green-300' : 'text-white/70'
                )}>
                  {line.type === 'added' && <span className="text-green-400 mr-1">+</span>}
                  {line.content || ' '}
                </span>
              </div>
            )
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Diff Modal Wrapper ───────────────────────────────────────────────────

interface DiffModalProps {
  isOpen: boolean
  onClose: () => void
  oldCode: string
  newCode: string
}

export function DiffModal({ isOpen, onClose, oldCode, newCode }: DiffModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-5xl h-[70vh] animate-fade-in-up">
        <DiffViewer oldCode={oldCode} newCode={newCode} onClose={onClose} />
      </div>
    </div>
  )
}
