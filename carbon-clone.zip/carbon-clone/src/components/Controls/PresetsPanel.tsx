import React, { useState } from 'react'
import { useEditorStore } from '@/store/editorStore'
import type { Preset } from '@/types'
import clsx from 'clsx'

// ─── Built-in Presets ─────────────────────────────────────────────────────

const PRESETS: Preset[] = [
  {
    id: 'aurora',
    name: 'Aurora',
    description: 'Northern lights gradient with Tokyo Night theme',
    config: {
      editor: { theme: 'tokyo-night' } as any,
      background: {
        type: 'gradient',
        solid: '#1a1b26',
        gradient: {
          angle: 135,
          stops: [
            { color: '#0a0e27', position: 0 },
            { color: '#0d3b5e', position: 40 },
            { color: '#16213e', position: 70 },
            { color: '#0a2744', position: 100 },
          ],
        },
        imageUrl: '',
        blur: 0,
      },
      shadow: { enabled: true, x: 0, y: 24, blur: 80, spread: 0, color: 'rgba(0,100,200,0.35)', inset: false },
      window: { style: 'mac', buttonStyle: 'colorful', title: '', showTitle: false, showLine: true },
      borderRadius: 16,
    },
  },
  {
    id: 'obsidian',
    name: 'Obsidian',
    description: 'Pure dark with deep shadow',
    config: {
      editor: { theme: 'vesper' } as any,
      background: {
        type: 'solid',
        solid: '#0a0a0a',
        gradient: { angle: 135, stops: [] },
        imageUrl: '',
        blur: 0,
      },
      shadow: { enabled: true, x: 0, y: 32, blur: 96, spread: -8, color: 'rgba(0,0,0,0.8)', inset: false },
      window: { style: 'mac', buttonStyle: 'mono', title: '', showTitle: false, showLine: false },
      borderRadius: 8,
    },
  },
  {
    id: 'candy',
    name: 'Candy',
    description: 'Vibrant pastel gradient with Dracula',
    config: {
      editor: { theme: 'dracula' } as any,
      background: {
        type: 'gradient',
        solid: '#ff79c6',
        gradient: {
          angle: 160,
          stops: [
            { color: '#f093fb', position: 0 },
            { color: '#f5576c', position: 45 },
            { color: '#fda085', position: 100 },
          ],
        },
        imageUrl: '',
        blur: 0,
      },
      shadow: { enabled: true, x: 0, y: 20, blur: 60, spread: 0, color: 'rgba(240,90,150,0.4)', inset: false },
      window: { style: 'mac', buttonStyle: 'colorful', title: '', showTitle: false, showLine: true },
      borderRadius: 20,
    },
  },
  {
    id: 'nord',
    name: 'Nord',
    description: 'Arctic, north-bluish color palette',
    config: {
      editor: { theme: 'nord' } as any,
      background: {
        type: 'solid',
        solid: '#3b4252',
        gradient: { angle: 135, stops: [] },
        imageUrl: '',
        blur: 0,
      },
      shadow: { enabled: true, x: 0, y: 16, blur: 48, spread: 0, color: 'rgba(46,52,64,0.6)', inset: false },
      window: { style: 'mac', buttonStyle: 'mono', title: '', showTitle: false, showLine: true },
      borderRadius: 10,
    },
  },
  {
    id: 'sunset',
    name: 'Sunset',
    description: 'Warm orange-purple sunset vibes',
    config: {
      editor: { theme: 'synthwave-84' } as any,
      background: {
        type: 'gradient',
        solid: '#FF6B6B',
        gradient: {
          angle: 45,
          stops: [
            { color: '#FF6B6B', position: 0 },
            { color: '#FFA500', position: 30 },
            { color: '#c471ed', position: 70 },
            { color: '#12c2e9', position: 100 },
          ],
        },
        imageUrl: '',
        blur: 0,
      },
      shadow: { enabled: true, x: 0, y: 28, blur: 88, spread: 0, color: 'rgba(196,113,237,0.45)', inset: false },
      window: { style: 'mac', buttonStyle: 'colorful', title: '', showTitle: false, showLine: true },
      borderRadius: 18,
    },
  },
  {
    id: 'matrix',
    name: 'Matrix',
    description: 'Green on black, terminal aesthetic',
    config: {
      editor: { theme: 'vitesse-dark' } as any,
      background: {
        type: 'solid',
        solid: '#000000',
        gradient: { angle: 135, stops: [] },
        imageUrl: '',
        blur: 0,
      },
      shadow: { enabled: true, x: 0, y: 0, blur: 40, spread: 8, color: 'rgba(0,255,65,0.2)', inset: false },
      window: { style: 'none', buttonStyle: 'mono', title: '', showTitle: false, showLine: false },
      borderRadius: 4,
    },
  },
  {
    id: 'catppuccin',
    name: 'Catppuccin',
    description: 'Soothing pastel theme for mocha lovers',
    config: {
      editor: { theme: 'catppuccin-mocha' } as any,
      background: {
        type: 'gradient',
        solid: '#1e1e2e',
        gradient: {
          angle: 120,
          stops: [
            { color: '#1e1e2e', position: 0 },
            { color: '#181825', position: 100 },
          ],
        },
        imageUrl: '',
        blur: 0,
      },
      shadow: { enabled: true, x: 0, y: 20, blur: 64, spread: 0, color: 'rgba(30,30,46,0.7)', inset: false },
      window: { style: 'mac', buttonStyle: 'colorful', title: '', showTitle: false, showLine: true },
      borderRadius: 14,
    },
  },
  {
    id: 'newspaper',
    name: 'Newspaper',
    description: 'Light minimal, GitHub Light theme',
    config: {
      editor: { theme: 'github-light' } as any,
      background: {
        type: 'solid',
        solid: '#f6f8fa',
        gradient: { angle: 135, stops: [] },
        imageUrl: '',
        blur: 0,
      },
      shadow: { enabled: true, x: 0, y: 8, blur: 32, spread: 0, color: 'rgba(0,0,0,0.15)', inset: false },
      window: { style: 'mac', buttonStyle: 'colorful', title: '', showTitle: false, showLine: true },
      borderRadius: 12,
    },
  },
]

// ─── Preset Preview Swatch ────────────────────────────────────────────────

function PresetSwatch({ preset }: { preset: Preset }) {
  const bg = preset.config.background!

  let bgStyle: React.CSSProperties = {}
  if (bg.type === 'solid') {
    bgStyle = { background: bg.solid }
  } else if (bg.type === 'gradient') {
    const stops = bg.gradient.stops
      .sort((a, b) => a.position - b.position)
      .map(s => `${s.color} ${s.position}%`)
      .join(', ')
    bgStyle = { background: `linear-gradient(${bg.gradient.angle}deg, ${stops})` }
  }

  // Window chrome bar color
  const isLight = bg.type === 'solid' && (bg.solid === '#f6f8fa' || bg.solid === '#ffffff')
  const cardBg = isLight ? '#ffffff' : 'rgba(0,0,0,0.45)'

  return (
    <div className="h-12 rounded-lg overflow-hidden relative" style={bgStyle}>
      <div
        className="absolute bottom-0 left-2 right-2 bottom-1 h-7 rounded-md flex items-center px-2 gap-1"
        style={{ background: cardBg, backdropFilter: 'blur(8px)' }}
      >
        {preset.config.window?.style === 'mac' && (
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-red-400/70" />
            <div className="w-1.5 h-1.5 rounded-full bg-yellow-400/70" />
            <div className="w-1.5 h-1.5 rounded-full bg-green-400/70" />
          </div>
        )}
        <div className="flex-1 flex flex-col gap-0.5 ml-1">
          <div className="h-0.5 rounded-full bg-white/20 w-3/4" />
          <div className="h-0.5 rounded-full bg-white/15 w-1/2" />
          <div className="h-0.5 rounded-full bg-white/20 w-2/3" />
        </div>
      </div>
    </div>
  )
}

// ─── Presets Panel ────────────────────────────────────────────────────────

export function PresetsPanel() {
  const store = useEditorStore()
  const [applied, setApplied] = useState<string | null>(null)

  function applyPreset(preset: Preset) {
    store.applyPreset(preset.config)
    setApplied(preset.id)
    setTimeout(() => setApplied(null), 2000)
  }

  return (
    <div className="p-4 space-y-3">
      <p className="text-[11px] text-white/30 uppercase tracking-widest font-semibold">Presets</p>
      <div className="grid grid-cols-2 gap-2">
        {PRESETS.map(preset => (
          <button
            key={preset.id}
            onClick={() => applyPreset(preset)}
            className={clsx(
              'text-left rounded-xl overflow-hidden border transition-all group',
              applied === preset.id
                ? 'border-green-500/50 ring-1 ring-green-500/30'
                : 'border-white/[0.06] hover:border-white/20'
            )}
          >
            <PresetSwatch preset={preset} />
            <div className="px-2.5 py-2 bg-white/[0.03] group-hover:bg-white/[0.06] transition-colors">
              <p className="text-xs font-semibold text-white/80">{preset.name}</p>
              <p className="text-[10px] text-white/35 leading-snug mt-0.5">{preset.description}</p>
            </div>
            {applied === preset.id && (
              <div className="absolute inset-0 flex items-center justify-center bg-green-900/30 text-green-400 text-sm">
                ✓ Applied
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  )
}


