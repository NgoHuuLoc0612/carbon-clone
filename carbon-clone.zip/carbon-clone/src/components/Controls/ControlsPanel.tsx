import React, { useState, useCallback } from 'react'
import { useEditorStore } from '@/store/editorStore'
import { SHIKI_THEMES } from '@/hooks/useShiki'
import { CODING_FONTS, useGoogleFonts } from '@/hooks/useGoogleFonts'
import { HexColorPicker, HexColorInput } from 'react-colorful'
import clsx from 'clsx'

// ─── Shared UI Primitives ─────────────────────────────────────────────────

function Label({ children }: { children: React.ReactNode }) {
  return (
    <label className="block text-[11px] font-semibold uppercase tracking-widest text-white/30 mb-1.5">
      {children}
    </label>
  )
}

function SliderInput({
  label, value, min, max, step = 1, unit = '',
  onChange,
}: {
  label: string; value: number; min: number; max: number; step?: number; unit?: string
  onChange: (v: number) => void
}) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center">
        <Label>{label}</Label>
        <span className="text-xs font-mono text-white/50">{value}{unit}</span>
      </div>
      <input
        type="range"
        min={min} max={max} step={step} value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full h-1 appearance-none rounded-full bg-white/10 cursor-pointer accent-indigo-500"
      />
    </div>
  )
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-white/70">{label}</span>
      <button
        onClick={onChange}
        className={clsx(
          'relative w-9 h-5 rounded-full transition-colors duration-200',
          checked ? 'bg-indigo-600' : 'bg-white/10'
        )}
      >
        <span className={clsx(
          'absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform duration-200',
          checked ? 'translate-x-4' : 'translate-x-0'
        )} />
      </button>
    </div>
  )
}

function NumberInput({ value, min, max, step = 1, onChange }: {
  value: number; min: number; max: number; step?: number; onChange: (v: number) => void
}) {
  return (
    <input
      type="number"
      value={value} min={min} max={max} step={step}
      onChange={e => onChange(Number(e.target.value))}
      className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white font-mono focus:outline-none focus:border-indigo-500/50 focus:bg-white/8 transition-colors"
    />
  )
}

function Select<T extends string>({
  value, options, onChange,
}: {
  value: T; options: Array<{ value: T; label: string }>; onChange: (v: T) => void
}) {
  return (
    <select
      value={value}
      onChange={e => onChange(e.target.value as T)}
      className="w-full bg-[#1a1d24] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500/50 cursor-pointer appearance-none"
    >
      {options.map(o => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
  )
}

// ─── Color Picker Popover ─────────────────────────────────────────────────

function ColorPicker({ color, onChange, label }: { color: string; onChange: (c: string) => void; label?: string }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="relative">
      {label && <Label>{label}</Label>}
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 hover:bg-white/8 transition-colors"
      >
        <span
          className="w-5 h-5 rounded-md border border-white/10 flex-shrink-0"
          style={{ background: color }}
        />
        <span className="text-sm font-mono text-white/70 uppercase">{color}</span>
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute z-50 top-full mt-2 left-0 bg-[#1a1d24] border border-white/10 rounded-xl p-3 shadow-2xl shadow-black/50">
            <HexColorPicker color={color} onChange={onChange} />
            <div className="mt-2 flex items-center gap-2">
              <span className="text-white/40 text-xs">#</span>
              <HexColorInput
                color={color}
                onChange={onChange}
                className="flex-1 bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-sm font-mono text-white focus:outline-none focus:border-indigo-500/50 uppercase"
              />
            </div>
          </div>
        </>
      )}
    </div>
  )
}

// ─── Background Panel ─────────────────────────────────────────────────────

function BackgroundPanel() {
  const store = useEditorStore()
  const { background: bg } = store

  return (
    <div className="space-y-4">
      {/* Type selector */}
      <div>
        <Label>Background Type</Label>
        <div className="grid grid-cols-4 gap-1 bg-white/5 p-1 rounded-lg">
          {(['solid', 'gradient', 'image', 'transparent'] as const).map(type => (
            <button
              key={type}
              onClick={() => store.setBackgroundType(type)}
              className={clsx(
                'py-1.5 rounded-md text-xs font-medium capitalize transition-all',
                bg.type === type
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'text-white/40 hover:text-white/70'
              )}
            >
              {type === 'transparent' ? 'None' : type}
            </button>
          ))}
        </div>
      </div>

      {bg.type === 'solid' && (
        <ColorPicker label="Color" color={bg.solid} onChange={store.setBackgroundSolid} />
      )}

      {bg.type === 'gradient' && (
        <div className="space-y-3">
          <SliderInput
            label="Angle" value={bg.gradient.angle}
            min={0} max={360} unit="°"
            onChange={store.setGradientAngle}
          />
          <div>
            <Label>Gradient Stops</Label>
            <div className="space-y-2">
              {bg.gradient.stops.map((stop, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span
                    className="w-6 h-6 rounded-md border border-white/10 flex-shrink-0 cursor-pointer"
                    style={{ background: stop.color }}
                  />
                  <input
                    type="text"
                    value={stop.color}
                    onChange={e => {
                      const stops = [...bg.gradient.stops]
                      stops[i] = { ...stops[i], color: e.target.value }
                      store.setGradientStops(stops)
                    }}
                    className="flex-1 bg-white/5 border border-white/10 rounded px-2 py-1 text-xs font-mono text-white focus:outline-none"
                  />
                  <input
                    type="range" min={0} max={100}
                    value={stop.position}
                    onChange={e => {
                      const stops = [...bg.gradient.stops]
                      stops[i] = { ...stops[i], position: Number(e.target.value) }
                      store.setGradientStops(stops)
                    }}
                    className="w-20 h-1 accent-indigo-500"
                  />
                  <span className="text-xs text-white/30 w-8 text-right">{stop.position}%</span>
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-2">
              <button
                onClick={() => {
                  const stops = [...bg.gradient.stops, { color: '#ffffff', position: 100 }]
                  store.setGradientStops(stops)
                }}
                className="text-xs text-indigo-400 hover:text-indigo-300"
              >
                + Add stop
              </button>
              {bg.gradient.stops.length > 2 && (
                <button
                  onClick={() => {
                    const stops = bg.gradient.stops.slice(0, -1)
                    store.setGradientStops(stops)
                  }}
                  className="text-xs text-red-400/70 hover:text-red-400"
                >
                  − Remove last
                </button>
              )}
            </div>
          </div>

          {/* Preview swatch */}
          <div
            className="h-8 rounded-lg border border-white/10"
            style={{
              background: `linear-gradient(${bg.gradient.angle}deg, ${bg.gradient.stops.map(s => `${s.color} ${s.position}%`).join(', ')})`,
            }}
          />
        </div>
      )}

      {bg.type === 'image' && (
        <div className="space-y-3">
          <div>
            <Label>Image URL</Label>
            <input
              type="text"
              value={bg.imageUrl}
              onChange={e => store.setBackgroundImage(e.target.value)}
              placeholder="https://..."
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500/50"
            />
          </div>
          <SliderInput label="Blur" value={bg.blur} min={0} max={20} unit="px" onChange={store.setBackgroundBlur} />
        </div>
      )}
    </div>
  )
}

// ─── Window Panel ─────────────────────────────────────────────────────────

function WindowPanel() {
  const store = useEditorStore()
  const { window: w } = store

  return (
    <div className="space-y-4">
      <div>
        <Label>Style</Label>
        <div className="grid grid-cols-3 gap-1 bg-white/5 p-1 rounded-lg">
          {(['mac', 'windows', 'none'] as const).map(s => (
            <button
              key={s}
              onClick={() => store.setWindowStyle(s)}
              className={clsx(
                'py-1.5 rounded-md text-xs font-medium capitalize transition-all',
                w.style === s ? 'bg-indigo-600 text-white' : 'text-white/40 hover:text-white/70'
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {w.style !== 'none' && (
        <>
          <div>
            <Label>Button Style</Label>
            <div className="grid grid-cols-3 gap-1 bg-white/5 p-1 rounded-lg">
              {(['colorful', 'mono', 'outline'] as const).map(s => (
                <button
                  key={s}
                  onClick={() => store.setWindowButtonStyle(s)}
                  className={clsx(
                    'py-1.5 rounded-md text-xs font-medium capitalize transition-all',
                    w.buttonStyle === s ? 'bg-indigo-600 text-white' : 'text-white/40 hover:text-white/70'
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <Toggle label="Show Title" checked={w.showTitle} onChange={store.toggleWindowTitle} />

          {w.showTitle && (
            <div>
              <Label>Title</Label>
              <input
                type="text"
                value={w.title}
                onChange={e => store.setWindowTitle(e.target.value)}
                placeholder="filename.ts"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500/50"
              />
            </div>
          )}

          <Toggle label="Divider Line" checked={w.showLine} onChange={() => store.setWindowStyle(w.style)} />
        </>
      )}
    </div>
  )
}

// ─── Shadow Panel ─────────────────────────────────────────────────────────

function ShadowPanel() {
  const store = useEditorStore()
  const { shadow } = store

  return (
    <div className="space-y-4">
      <Toggle label="Enable Shadow" checked={shadow.enabled} onChange={store.toggleShadow} />

      {shadow.enabled && (
        <>
          <SliderInput label="Offset X" value={shadow.x} min={-50} max={50} unit="px"
            onChange={v => store.setShadow({ x: v })} />
          <SliderInput label="Offset Y" value={shadow.y} min={-50} max={100} unit="px"
            onChange={v => store.setShadow({ y: v })} />
          <SliderInput label="Blur" value={shadow.blur} min={0} max={100} unit="px"
            onChange={v => store.setShadow({ blur: v })} />
          <SliderInput label="Spread" value={shadow.spread} min={-20} max={50} unit="px"
            onChange={v => store.setShadow({ spread: v })} />
          <ColorPicker label="Color" color={shadow.color.startsWith('rgba') ? '#000000' : shadow.color}
            onChange={c => store.setShadow({ color: c })} />
          <Toggle label="Inset" checked={shadow.inset} onChange={() => store.setShadow({ inset: !shadow.inset })} />

          {/* Live preview */}
          <div className="h-10 rounded-lg bg-[#1a1d24] border border-white/10 transition-all duration-200"
            style={{
              boxShadow: `${shadow.inset ? 'inset ' : ''}${shadow.x}px ${shadow.y}px ${shadow.blur}px ${shadow.spread}px ${shadow.color}`
            }} />
        </>
      )}
    </div>
  )
}

// ─── Typography Panel ─────────────────────────────────────────────────────

function TypographyPanel() {
  const store = useEditorStore()
  const { editor } = store
  const { searchFonts, loadFont } = useGoogleFonts()
  const [fontSearch, setFontSearch] = useState('')
  const filteredFonts = searchFonts(fontSearch)

  return (
    <div className="space-y-4">
      <div>
        <Label>Font Family</Label>
        <input
          type="text"
          value={fontSearch}
          onChange={e => setFontSearch(e.target.value)}
          placeholder="Search fonts..."
          className="w-full mb-2 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-indigo-500/50"
        />
        <select
          value={editor.fontFamily}
          onChange={async e => {
            const family = e.target.value
            store.setFontFamily(family)
            await loadFont(family)
          }}
          size={5}
          className="w-full bg-[#1a1d24] border border-white/10 rounded-lg text-sm text-white focus:outline-none"
          style={{ scrollbarWidth: 'thin' }}
        >
          {filteredFonts.map(f => (
            <option key={f.family} value={f.family}
              style={{ fontFamily: `'${f.family}', monospace`, padding: '4px 8px' }}>
              {f.family}
            </option>
          ))}
        </select>
      </div>

      <SliderInput label="Size" value={editor.fontSize} min={10} max={24} unit="px"
        onChange={store.setFontSize} />
      <SliderInput label="Line Height" value={editor.lineHeight} min={1} max={2.5} step={0.05}
        onChange={store.setLineHeight} />

      <div>
        <Label>Tab Size</Label>
        <div className="grid grid-cols-4 gap-1 bg-white/5 p-1 rounded-lg">
          {[2, 4, 6, 8].map(ts => (
            <button
              key={ts}
              onClick={() => store.setTabSize(ts)}
              className={clsx(
                'py-1.5 rounded-md text-xs font-mono font-medium transition-all',
                editor.tabSize === ts ? 'bg-indigo-600 text-white' : 'text-white/40 hover:text-white/70'
              )}
            >
              {ts}
            </button>
          ))}
        </div>
      </div>

      <Toggle label="Line Numbers" checked={editor.showLineNumbers} onChange={store.toggleLineNumbers} />

      {editor.showLineNumbers && (
        <div>
          <Label>First Line Number</Label>
          <NumberInput value={editor.firstLineNumber} min={0} max={9999} onChange={store.setFirstLineNumber} />
        </div>
      )}

      <Toggle label="Word Wrap" checked={editor.wrapLines} onChange={store.toggleWrapLines} />
      <Toggle label="Show Whitespace" checked={editor.showWhiteSpace} onChange={store.toggleWhiteSpace} />
    </div>
  )
}

// ─── Theme Panel ──────────────────────────────────────────────────────────

function ThemePanel() {
  const store = useEditorStore()
  const { editor } = store
  const [search, setSearch] = useState('')
  const filtered = SHIKI_THEMES.filter(t => t.name.toLowerCase().includes(search.toLowerCase()))
  const dark = filtered.filter(t => t.type === 'dark')
  const light = filtered.filter(t => t.type === 'light')

  return (
    <div className="space-y-3">
      <input
        type="text"
        value={search}
        onChange={e => setSearch(e.target.value)}
        placeholder="Search themes..."
        className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-indigo-500/50"
      />

      {dark.length > 0 && (
        <div>
          <Label>Dark Themes</Label>
          <div className="space-y-1 max-h-52 overflow-y-auto pr-1" style={{ scrollbarWidth: 'thin' }}>
            {dark.map(theme => (
              <button
                key={theme.id}
                onClick={() => store.setTheme(theme.id)}
                className={clsx(
                  'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all text-left',
                  editor.theme === theme.id
                    ? 'bg-indigo-600/30 text-indigo-300 ring-1 ring-indigo-500/50'
                    : 'text-white/70 hover:bg-white/5'
                )}
              >
                <span className="w-4 h-4 rounded-sm border border-white/10 flex-shrink-0"
                  style={{ background: theme.preview }} />
                {theme.name}
                {editor.theme === theme.id && (
                  <span className="ml-auto text-indigo-400">✓</span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {light.length > 0 && (
        <div>
          <Label>Light Themes</Label>
          <div className="space-y-1">
            {light.map(theme => (
              <button
                key={theme.id}
                onClick={() => store.setTheme(theme.id)}
                className={clsx(
                  'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all text-left',
                  editor.theme === theme.id
                    ? 'bg-indigo-600/30 text-indigo-300 ring-1 ring-indigo-500/50'
                    : 'text-white/70 hover:bg-white/5'
                )}
              >
                <span className="w-4 h-4 rounded-sm border border-white/10 flex-shrink-0"
                  style={{ background: theme.preview }} />
                {theme.name}
                {editor.theme === theme.id && (
                  <span className="ml-auto text-indigo-400">✓</span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Layout Panel ─────────────────────────────────────────────────────────

function LayoutPanel() {
  const store = useEditorStore()
  const { padding, borderRadius, width, watermark } = store

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-center justify-between mb-2">
          <Label>Padding</Label>
          <button
            onClick={() => store.setPadding({ linked: !padding.linked })}
            className={clsx('text-xs px-2 py-0.5 rounded', padding.linked ? 'bg-indigo-600/30 text-indigo-400' : 'text-white/30 hover:text-white/50')}
          >
            {padding.linked ? '⛓ Linked' : '⛓️‍💥 Unlinked'}
          </button>
        </div>

        {padding.linked ? (
          <SliderInput label="All sides" value={padding.top} min={0} max={128} unit="px"
            onChange={store.setPaddingAll} />
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {(['top', 'right', 'bottom', 'left'] as const).map(side => (
              <div key={side}>
                <Label>{side}</Label>
                <NumberInput
                  value={padding[side]}
                  min={0} max={128}
                  onChange={v => store.setPadding({ [side]: v })}
                />
              </div>
            ))}
          </div>
        )}
      </div>

      <SliderInput label="Border Radius" value={borderRadius} min={0} max={32} unit="px"
        onChange={store.setBorderRadius} />

      <div>
        <Label>Canvas Width</Label>
        <div className="flex gap-2">
          <button
            onClick={() => store.setWidth('auto')}
            className={clsx(
              'flex-1 py-1.5 rounded-lg text-xs font-medium transition-all',
              width === 'auto' ? 'bg-indigo-600 text-white' : 'bg-white/5 text-white/40 hover:text-white/70'
            )}
          >
            Auto
          </button>
          <input
            type="number"
            min={200} max={2400} step={10}
            value={typeof width === 'number' ? width : 680}
            onChange={e => store.setWidth(Number(e.target.value))}
            className="flex-1 bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-sm text-white font-mono focus:outline-none focus:border-indigo-500/50 text-center"
          />
          <span className="flex items-center text-xs text-white/30">px</span>
        </div>
      </div>

      <div className="border-t border-white/5 pt-4 space-y-3">
        <Toggle label="Watermark" checked={watermark.enabled} onChange={store.toggleWatermark} />
        {watermark.enabled && (
          <>
            <div>
              <Label>Text</Label>
              <input
                type="text"
                value={watermark.text}
                onChange={e => store.setWatermark({ text: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-indigo-500/50"
              />
            </div>
            <div>
              <Label>Position</Label>
              <Select
                value={watermark.position}
                options={[
                  { value: 'bottom-right', label: 'Bottom Right' },
                  { value: 'bottom-left', label: 'Bottom Left' },
                  { value: 'top-right', label: 'Top Right' },
                  { value: 'top-left', label: 'Top Left' },
                ]}
                onChange={v => store.setWatermark({ position: v })}
              />
            </div>
            <SliderInput label="Opacity" value={watermark.opacity} min={0.05} max={1} step={0.05}
              onChange={v => store.setWatermark({ opacity: v })} />
          </>
        )}
      </div>
    </div>
  )
}

// ─── Tab Types ────────────────────────────────────────────────────────────

const TABS = [
  { id: 'theme', label: '🎨 Theme', icon: '🎨' },
  { id: 'font', label: 'Aa Font', icon: 'Aa' },
  { id: 'background', label: '□ BG', icon: '□' },
  { id: 'window', label: '⊞ Window', icon: '⊞' },
  { id: 'shadow', label: '◫ Shadow', icon: '◫' },
  { id: 'layout', label: '⊡ Layout', icon: '⊡' },
]

// ─── Controls Panel ───────────────────────────────────────────────────────

export function ControlsPanel() {
  const [activeTab, setActiveTab] = useState('theme')

  return (
    <div className="flex flex-col h-full bg-[#12141a] border-r border-white/[0.06]">
      {/* Tab bar */}
      <div className="flex border-b border-white/[0.06] overflow-x-auto flex-shrink-0">
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={clsx(
              'flex-shrink-0 px-3.5 py-3 text-xs font-medium whitespace-nowrap transition-all border-b-2',
              activeTab === tab.id
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                : 'border-transparent text-white/40 hover:text-white/60 hover:bg-white/[0.03]'
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Panel content */}
      <div className="flex-1 overflow-y-auto p-4" style={{ scrollbarWidth: 'thin' }}>
        {activeTab === 'theme' && <ThemePanel />}
        {activeTab === 'font' && <TypographyPanel />}
        {activeTab === 'background' && <BackgroundPanel />}
        {activeTab === 'window' && <WindowPanel />}
        {activeTab === 'shadow' && <ShadowPanel />}
        {activeTab === 'layout' && <LayoutPanel />}
      </div>
    </div>
  )
}
