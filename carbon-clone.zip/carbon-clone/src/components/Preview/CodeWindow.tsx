import React, { forwardRef, useMemo } from 'react'
import { useEditorStore } from '@/store/editorStore'
import { useShiki } from '@/hooks/useShiki'
import { useGoogleFonts } from '@/hooks/useGoogleFonts'
import type { BackgroundConfig, ShadowConfig, WindowConfig } from '@/types'
import clsx from 'clsx'

// ─── Window Chrome ────────────────────────────────────────────────────────

function MacButtons({ style }: { style: WindowConfig['buttonStyle'] }) {
  if (style === 'colorful') {
    return (
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-full bg-[#ff5f57] border border-black/20 shadow-inner" />
        <div className="w-3 h-3 rounded-full bg-[#ffbd2e] border border-black/20 shadow-inner" />
        <div className="w-3 h-3 rounded-full bg-[#28c840] border border-black/20 shadow-inner" />
      </div>
    )
  }
  if (style === 'mono') {
    return (
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-full bg-white/25 border border-white/10" />
        <div className="w-3 h-3 rounded-full bg-white/25 border border-white/10" />
        <div className="w-3 h-3 rounded-full bg-white/25 border border-white/10" />
      </div>
    )
  }
  // outline
  return (
    <div className="flex items-center gap-2">
      <div className="w-3 h-3 rounded-full border border-white/30" />
      <div className="w-3 h-3 rounded-full border border-white/30" />
      <div className="w-3 h-3 rounded-full border border-white/30" />
    </div>
  )
}

function WindowsButtons({ style }: { style: WindowConfig['buttonStyle'] }) {
  const btnBase = 'w-4 h-4 flex items-center justify-center text-[10px] leading-none'

  if (style === 'colorful') {
    return (
      <div className="flex items-center gap-1">
        <div className={clsx(btnBase, 'text-yellow-300/80')}>—</div>
        <div className={clsx(btnBase, 'text-green-400/80')}>□</div>
        <div className={clsx(btnBase, 'bg-[#e81123] text-white rounded-sm')}>×</div>
      </div>
    )
  }
  return (
    <div className="flex items-center gap-1">
      <div className={clsx(btnBase, 'text-white/40')}>—</div>
      <div className={clsx(btnBase, 'text-white/40')}>□</div>
      <div className={clsx(btnBase, 'text-white/40')}>×</div>
    </div>
  )
}

function WindowChrome() {
  const { window: wCfg } = useEditorStore()

  if (wCfg.style === 'none') return null

  return (
    <div className={clsx(
      'flex items-center px-4 py-3 gap-2',
      wCfg.showLine && 'border-b border-white/[0.08]',
    )}>
      {wCfg.style === 'mac' ? (
        <>
          <MacButtons style={wCfg.buttonStyle} />
          {wCfg.showTitle && wCfg.title && (
            <span className="absolute left-1/2 -translate-x-1/2 text-xs text-white/50 font-medium tracking-wide">
              {wCfg.title}
            </span>
          )}
        </>
      ) : (
        <>
          {wCfg.showTitle && wCfg.title && (
            <span className="flex-1 text-xs text-white/50 font-medium tracking-wide pl-1">
              {wCfg.title}
            </span>
          )}
          <div className="ml-auto">
            <WindowsButtons style={wCfg.buttonStyle} />
          </div>
        </>
      )}
    </div>
  )
}

// ─── Background CSS ───────────────────────────────────────────────────────

function buildBackground(bg: BackgroundConfig): React.CSSProperties {
  if (bg.type === 'transparent') {
    return { background: 'transparent' }
  }
  if (bg.type === 'solid') {
    return { background: bg.solid }
  }
  if (bg.type === 'gradient') {
    const stops = bg.gradient.stops
      .sort((a, b) => a.position - b.position)
      .map(s => `${s.color} ${s.position}%`)
      .join(', ')
    return { background: `linear-gradient(${bg.gradient.angle}deg, ${stops})` }
  }
  if (bg.type === 'image' && bg.imageUrl) {
    return {
      backgroundImage: `url(${bg.imageUrl})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      ...(bg.blur > 0 ? { backdropFilter: `blur(${bg.blur}px)` } : {}),
    }
  }
  return {}
}

function buildShadow(shadow: ShadowConfig): React.CSSProperties {
  if (!shadow.enabled) return {}
  const { x, y, blur, spread, color, inset } = shadow
  return {
    boxShadow: `${inset ? 'inset ' : ''}${x}px ${y}px ${blur}px ${spread}px ${color}`,
  }
}

// ─── Line Numbers Gutter ──────────────────────────────────────────────────

function LineNumbers({ code, startFrom, color }: { code: string; startFrom: number; color: string }) {
  const lines = code.split('\n')
  return (
    <div
      className="select-none pr-4 text-right"
      style={{
        color: color + '60',
        minWidth: '3ch',
        userSelect: 'none',
      }}
    >
      {lines.map((_, i) => (
        <div key={i} style={{ height: 'inherit', lineHeight: 'inherit' }}>
          {i + startFrom}
        </div>
      ))}
    </div>
  )
}

// ─── Shiki HTML Renderer ─────────────────────────────────────────────────

function ShikiCodeRenderer({
  html,
  fg,
  fontFamily,
  fontSize,
  lineHeight,
  showLineNumbers,
  firstLineNumber,
  tabSize,
}: {
  html: string
  fg: string
  fontFamily: string
  fontSize: number
  lineHeight: number
  showLineNumbers: boolean
  firstLineNumber: number
  tabSize: number
}) {
  // Strip outer pre/code tags from shiki HTML and rebuild with our styling
  const innerHtml = html
    .replace(/^<pre[^>]*>/, '')
    .replace(/<\/pre>$/, '')

  return (
    <div
      className="relative overflow-auto"
      style={{
        fontFamily: `'${fontFamily}', 'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace`,
        fontSize: `${fontSize}px`,
        lineHeight: lineHeight,
        color: fg,
        tabSize,
      }}
    >
      <div
        className="min-w-0"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: innerHtml }}
        style={{
          // Override shiki's default styles
          ['--shiki-bg' as string]: 'transparent',
        }}
      />
    </div>
  )
}

// ─── Watermark ────────────────────────────────────────────────────────────

function Watermark() {
  const { watermark } = useEditorStore()
  if (!watermark.enabled) return null

  const positionClass = {
    'bottom-right': 'bottom-3 right-4',
    'bottom-left': 'bottom-3 left-4',
    'top-right': 'top-3 right-4',
    'top-left': 'top-3 left-4',
  }[watermark.position]

  return (
    <div
      className={clsx('absolute text-xs font-mono pointer-events-none', positionClass)}
      style={{ opacity: watermark.opacity, color: 'white' }}
    >
      {watermark.text}
    </div>
  )
}

// ─── Main Code Window ─────────────────────────────────────────────────────

export const CodeWindow = forwardRef<HTMLDivElement>((_, ref) => {
  const store = useEditorStore()
  const { editor, background, shadow, padding, borderRadius, width } = store
  const { loadFont } = useGoogleFonts()

  // Load the selected font
  React.useEffect(() => {
    loadFont(editor.fontFamily, ['300', 'regular', '500', '600', '700'])
  }, [editor.fontFamily, loadFont])

  const { highlighted, loading } = useShiki({
    code: editor.code,
    language: editor.language,
    theme: editor.theme,
  })

  const bgStyle = useMemo(() => buildBackground(background), [background])
  const shadowStyle = useMemo(() => buildShadow(shadow), [shadow])

  const containerStyle: React.CSSProperties = {
    ...bgStyle,
    padding: `${padding.top}px ${padding.right}px ${padding.bottom}px ${padding.left}px`,
    display: 'inline-block',
    width: width === 'auto' ? 'auto' : `${width}px`,
    minWidth: 320,
    position: 'relative',
  }

  const windowStyle: React.CSSProperties = {
    ...shadowStyle,
    borderRadius: `${borderRadius}px`,
    overflow: 'hidden',
    backgroundColor: highlighted?.bg || '#0d1117',
    backdropFilter: 'blur(0px)',
  }

  return (
    <div ref={ref} style={containerStyle} className="relative">
      <div style={windowStyle}>
        <div className="relative">
          <WindowChrome />

          <div
            className="relative"
            style={{
              backgroundColor: highlighted?.bg || '#0d1117',
            }}
          >
            {loading ? (
              <div
                className="px-6 py-4 font-mono text-sm opacity-40"
                style={{ color: '#e6edf3' }}
              >
                <pre>{editor.code}</pre>
              </div>
            ) : highlighted ? (
              <div className="flex">
                {editor.showLineNumbers && (
                  <div
                    className="flex-shrink-0 pt-[20px] pb-[20px] pl-4"
                    style={{
                      fontFamily: `'${editor.fontFamily}', monospace`,
                      fontSize: `${editor.fontSize}px`,
                      lineHeight: editor.lineHeight,
                      color: highlighted.fg,
                      userSelect: 'none',
                    }}
                  >
                    <LineNumbers
                      code={editor.code}
                      startFrom={editor.firstLineNumber}
                      color={highlighted.fg}
                    />
                  </div>
                )}
                <div className="flex-1 min-w-0 overflow-x-auto">
                  <div
                    className="px-6 py-[20px]"
                    style={{
                      fontFamily: `'${editor.fontFamily}', 'JetBrains Mono', monospace`,
                      fontSize: `${editor.fontSize}px`,
                      lineHeight: editor.lineHeight,
                    }}
                  >
                    <ShikiCodeRenderer
                      html={highlighted.html}
                      fg={highlighted.fg}
                      fontFamily={editor.fontFamily}
                      fontSize={editor.fontSize}
                      lineHeight={editor.lineHeight}
                      showLineNumbers={false} // Handled above
                      firstLineNumber={editor.firstLineNumber}
                      tabSize={editor.tabSize}
                    />
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      <Watermark />
    </div>
  )
})

CodeWindow.displayName = 'CodeWindow'

// ─── Global Shiki Style Override ─────────────────────────────────────────

const SHIKI_GLOBAL_STYLE = `
  .shiki, .shiki code, .shiki pre {
    background: transparent !important;
    font-family: inherit !important;
    font-size: inherit !important;
    line-height: inherit !important;
    tab-size: inherit !important;
  }
  .shiki .line {
    display: block;
    min-height: 1em;
  }
`

export function ShikiStyleInjector() {
  return <style dangerouslySetInnerHTML={{ __html: SHIKI_GLOBAL_STYLE }} />
}
